package kr.koala.korime_scene;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import org.jetbrains.annotations.Nullable;

public final class SmartphoneBlock extends class_2383 implements class_2343 {
    public static final MapCodec<SmartphoneBlock> CODEC = method_54094(SmartphoneBlock::new);
    private static final class_265 NORTH_SOUTH = class_2248.method_9541(4.0, 0.0, 2.0, 12.0, 1.0, 14.0);
    private static final class_265 EAST_WEST = class_2248.method_9541(2.0, 0.0, 4.0, 14.0, 1.0, 12.0);

    public SmartphoneBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override protected MapCodec<? extends class_2383> method_53969() { return field_46280; }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(field_11177, context.method_8042());
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(field_11177).method_10166() == class_2350.class_2351.field_11048 ? EAST_WEST : NORTH_SOUTH;
    }

    @Override public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) { return new SmartphoneBlockEntity(pos, state); }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, @Nullable class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (!world.field_9236 && world.method_8321(pos) instanceof SmartphoneBlockEntity phone) phone.setData(SmartphoneData.fromStack(itemStack));
    }

    @Override
    public class_2680 method_9576(class_1937 world, class_2338 pos, class_2680 state, class_1657 player) {
        if (!world.field_9236 && !player.method_31549().field_7477 && world.method_8321(pos) instanceof SmartphoneBlockEntity phone) {
            class_2248.method_9577(world, pos, phone.createPhoneStack());
        }
        return super.method_9576(world, pos, state, player);
    }

    @Override public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) { return class_1269.field_5812; }

    @Override
    public class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state) {
        class_2586 blockEntity = world.method_8321(pos);
        return blockEntity instanceof SmartphoneBlockEntity phone ? phone.createPhoneStack() : new class_1799(SmartphoneMod.SMARTPHONE);
    }

    @Override public class_2680 method_9598(class_2680 state, class_2470 rotation) { return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177))); }
    @Override public class_2680 method_9569(class_2680 state, class_2415 mirror) { return state.method_26186(mirror.method_10345(state.method_11654(field_11177))); }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) { builder.method_11667(field_11177); }
}
