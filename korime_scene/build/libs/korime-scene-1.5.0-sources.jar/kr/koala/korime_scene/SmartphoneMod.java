package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public final class SmartphoneMod implements ModInitializer {
    public static final class_2960 SAVE_PACKET = new class_2960(KorimeSceneMod.MOD_ID, "smartphone_save");

    public static final class_2248 SMARTPHONE_BLOCK = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960(KorimeSceneMod.MOD_ID, "smartphone"),
            new SmartphoneBlock(class_4970.class_2251.method_9637()
                    .method_9632(0.25F)
                    .method_9626(class_2498.field_11533)
                    .method_22488())
    );

    public static final class_2591<SmartphoneBlockEntity> SMARTPHONE_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(KorimeSceneMod.MOD_ID, "smartphone"),
            FabricBlockEntityTypeBuilder.create(SmartphoneBlockEntity::new, SMARTPHONE_BLOCK).build()
    );

    public static final class_1792 SMARTPHONE = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(KorimeSceneMod.MOD_ID, "smartphone"),
            new SmartphoneItem(SMARTPHONE_BLOCK, new class_1792.class_1793().method_7889(1))
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> entries.method_45421(SMARTPHONE));

        ServerPlayNetworking.registerGlobalReceiver(SAVE_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    final class_1268 hand;
                    final SmartphoneData data;
                    try {
                        hand = buf.method_10818(class_1268.class);
                        data = SmartphoneData.readPacket(buf);
                    } catch (RuntimeException ignored) {
                        return;
                    }

                    server.execute(() -> {
                        class_1799 stack = player.method_5998(hand);
                        if (!stack.method_31574(SMARTPHONE)) {
                            return;
                        }
                        // A finalized phone is immutable, like a signed written book.
                        if (SmartphoneData.fromStack(stack).finalized()) {
                            return;
                        }
                        data.writeTo(stack);
                        player.field_7512.method_7623();
                    });
                });
    }
}
