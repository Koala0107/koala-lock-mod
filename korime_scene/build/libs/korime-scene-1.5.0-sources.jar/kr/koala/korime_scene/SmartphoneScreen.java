package kr.koala.korime_scene;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

public final class SmartphoneScreen extends class_437 {
    private static final int PAGE_SIZE = 5;
    private static final int ROW_HEIGHT = 25;

    private final class_1268 hand;
    private final List<SmartphoneData.PhoneRecord> calls;
    private final List<SmartphoneData.PhoneRecord> messages;

    private boolean showingCalls = true;
    private int page;
    private int selected = -1;
    private boolean synced;

    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;
    private int listX;
    private int listY;
    private int listWidth;

    private class_4185 callsTab;
    private class_4185 messagesTab;
    private class_4185 previousPage;
    private class_4185 nextPage;
    private class_4185 addButton;
    private class_4185 applyButton;
    private class_4185 deleteButton;

    private class_342 nameField;
    private class_342 timeField;
    private class_342 detailField;

    public SmartphoneScreen(class_1268 hand, class_1799 stack) {
        super(class_2561.method_43471("screen.korime_scene.smartphone"));
        this.hand = hand;
        SmartphoneData data = SmartphoneData.fromStack(stack);
        this.calls = new ArrayList<>(data.calls());
        this.messages = new ArrayList<>(data.messages());
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(300, field_22789 - 12);
        panelHeight = Math.min(252, field_22790 - 8);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;

        int innerX = panelX + 15;
        int innerWidth = panelWidth - 30;
        listX = innerX;
        listY = panelY + 58;
        listWidth = innerWidth;

        callsTab = method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.calls"),
                        button -> switchMode(true))
                .method_46434(innerX, panelY + 35, (innerWidth - 4) / 2, 18)
                .method_46431());
        messagesTab = method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.messages"),
                        button -> switchMode(false))
                .method_46434(innerX + (innerWidth + 4) / 2, panelY + 35,
                        (innerWidth - 4) / 2, 18)
                .method_46431());

        previousPage = method_37063(class_4185.method_46430(class_2561.method_43470("‹"), button -> changePage(-1))
                .method_46434(innerX, panelY + 187, 28, 18)
                .method_46431());
        nextPage = method_37063(class_4185.method_46430(class_2561.method_43470("›"), button -> changePage(1))
                .method_46434(innerX + innerWidth - 28, panelY + 187, 28, 18)
                .method_46431());

        nameField = method_37063(new class_342(field_22793,
                innerX, panelY + 211, 94, 18, class_2561.method_43471("screen.korime_scene.smartphone.name")));
        nameField.method_1880(SmartphoneData.MAX_NAME_LENGTH);
        nameField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.name"));

        timeField = method_37063(new class_342(field_22793,
                innerX + 98, panelY + 211, 58, 18, class_2561.method_43471("screen.korime_scene.smartphone.time")));
        timeField.method_1880(SmartphoneData.MAX_TIME_LENGTH);
        timeField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.time"));

        detailField = method_37063(new class_342(field_22793,
                innerX + 160, panelY + 211, innerWidth - 160, 18,
                class_2561.method_43471("screen.korime_scene.smartphone.detail")));
        detailField.method_1880(SmartphoneData.MAX_DETAIL_LENGTH);
        detailField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.detail"));

        int actionGap = 4;
        int actionWidth = (innerWidth - actionGap * 2) / 3;
        addButton = method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.add"), button -> addRecord())
                .method_46434(innerX, panelY + 232, actionWidth, 16)
                .method_46431());
        applyButton = method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.apply"), button -> applyRecord())
                .method_46434(innerX + actionWidth + actionGap, panelY + 232, actionWidth, 16)
                .method_46431());
        deleteButton = method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.delete"), button -> deleteRecord())
                .method_46434(innerX + (actionWidth + actionGap) * 2, panelY + 232, actionWidth, 16)
                .method_46431());

        loadSelectedIntoFields();
        refreshWidgets();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context, mouseX, mouseY, delta);
        drawPhoneChrome(context);
        drawRecordList(context, mouseX, mouseY);

        List<SmartphoneData.PhoneRecord> records = activeRecords();
        int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        class_2561 status = class_2561.method_43469("screen.korime_scene.smartphone.page",
                page + 1, totalPages, records.size());
        context.method_27534(field_22793, status,
                panelX + panelWidth / 2, panelY + 192, 0xFFB9C8D6);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawPhoneChrome(class_332 context) {
        context.method_25294(panelX - 5, panelY - 4, panelX + panelWidth + 5, panelY + panelHeight + 5, 0x66000000);
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF050709);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF171D22);
        context.method_25294(panelX + 7, panelY + 7, panelX + panelWidth - 7, panelY + panelHeight - 7, 0xFFF3F3F3);

        context.method_25294(panelX + 8, panelY + 8, panelX + panelWidth - 8, panelY + 31, 0xFF28333D);
        context.method_25294(panelX + panelWidth / 2 - 24, panelY + 5,
                panelX + panelWidth / 2 + 18, panelY + 7, 0xFF050709);
        context.method_25294(panelX + panelWidth / 2 + 22, panelY + 5,
                panelX + panelWidth / 2 + 25, panelY + 8, 0xFF0A0D10);

        int iconColor = showingCalls ? 0xFF2FB55D : 0xFF318BEA;
        context.method_25294(panelX + 14, panelY + 13, panelX + 24, panelY + 23, iconColor);
        context.method_27535(field_22793, showingCalls ? class_2561.method_43470("☎") : class_2561.method_43470("✉"),
                panelX + 15, panelY + 13, 0xFFFFFFFF);
        context.method_27535(field_22793,
                showingCalls
                        ? class_2561.method_43471("screen.korime_scene.smartphone.calls")
                        : class_2561.method_43471("screen.korime_scene.smartphone.messages"),
                panelX + 30, panelY + 14, 0xFFFFFFFF);
        context.method_27535(field_22793, class_2561.method_43470("10:24"),
                panelX + panelWidth - 45, panelY + 14, 0xFFE7EDF3);

        context.method_25294(panelX + 10, panelY + 55, panelX + panelWidth - 10, panelY + 184, 0xFFFFFFFF);
        context.method_25294(panelX + 10, panelY + 55, panelX + panelWidth - 10, panelY + 56, 0xFFD0D4D8);
        context.method_25294(panelX + 10, panelY + 184, panelX + panelWidth - 10, panelY + 185, 0xFFD0D4D8);

        context.method_25294(panelX + 11, panelY + 207, panelX + panelWidth - 11, panelY + 231, 0xFFE8EBEE);
        context.method_25294(panelX + panelWidth / 2 - 23, panelY + panelHeight - 4,
                panelX + panelWidth / 2 + 23, panelY + panelHeight - 2, 0xFF8B949C);
    }

    private void drawRecordList(class_332 context, int mouseX, int mouseY) {
        List<SmartphoneData.PhoneRecord> records = activeRecords();

        for (int row = 0; row < PAGE_SIZE; row++) {
            int index = page * PAGE_SIZE + row;
            int y = listY + row * ROW_HEIGHT;
            boolean hovered = mouseX >= listX && mouseX < listX + listWidth
                    && mouseY >= y && mouseY < y + ROW_HEIGHT;
            boolean isSelected = index == selected;

            if (hovered || isSelected) {
                context.method_25294(listX, y, listX + listWidth, y + ROW_HEIGHT, isSelected ? 0xFFE6F1FB : 0xFFF1F4F6);
            }
            if (row > 0) {
                context.method_25294(listX + 34, y, listX + listWidth, y + 1, 0xFFE1E4E7);
            }

            if (index >= records.size()) {
                continue;
            }

            SmartphoneData.PhoneRecord record = records.get(index);
            String name = record.name().isBlank()
                    ? class_2561.method_43471("screen.korime_scene.smartphone.unnamed").getString()
                    : record.name();
            String time = record.time().isBlank() ? "--:--" : record.time();
            String detail = record.detail().isBlank() ? "..." : record.detail();

            drawAvatar(context, listX + 4, y + 4, index, showingCalls);

            context.method_51439(field_22793, class_2561.method_43470(field_22793.method_27523(name, listWidth - 96)),
                    listX + 38, y + 4, 0xFF1F252B, false);
            int timeWidth = field_22793.method_1727(time);
            context.method_51439(field_22793, class_2561.method_43470(time), listX + listWidth - timeWidth - 5,
                    y + 4, 0xFF6C747B, false);

            String secondary = showingCalls
                    ? callSecondaryText(detail)
                    : field_22793.method_27523(detail, listWidth - 52);
            int secondaryColor = showingCalls && isMissedCall(detail) ? 0xFFD83A3A : 0xFF707980;
            context.method_51439(field_22793, class_2561.method_43470(secondary), listX + 38, y + 14, secondaryColor, false);
        }
    }

    private void drawAvatar(class_332 context, int x, int y, int index, boolean callMode) {
        int[] palette = {0xFFBA704A, 0xFF6AA6D8, 0xFF63A875, 0xFF9A7AC2, 0xFFC09048, 0xFF70767C};
        int color = palette[Math.floorMod(index, palette.length)];
        context.method_25294(x, y, x + 26, y + 17, color);
        context.method_25294(x + 3, y + 3, x + 23, y + 14, 0x33000000);
        context.method_27534(field_22793,
                callMode ? class_2561.method_43470("☎") : class_2561.method_43470("✉"), x + 13, y + 4, 0xFFFFFFFF);
    }

    private String callSecondaryText(String detail) {
        if (detail.isBlank()) {
            return "☎  " + class_2561.method_43471("screen.korime_scene.smartphone.calls").getString();
        }
        String prefix = isMissedCall(detail) ? "↙  " : "↗  ";
        return prefix + field_22793.method_27523(detail, listWidth - 58);
    }

    private boolean isMissedCall(String detail) {
        String normalized = detail.toLowerCase();
        return normalized.contains("miss") || normalized.contains("부재") || normalized.contains("실패")
                || normalized.contains("못") || normalized.contains("끊");
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && mouseX >= listX && mouseX < listX + listWidth
                && mouseY >= listY && mouseY < listY + PAGE_SIZE * ROW_HEIGHT) {
            int row = class_3532.method_15357((mouseY - listY) / ROW_HEIGHT);
            int index = page * PAGE_SIZE + row;
            if (index < activeRecords().size()) {
                selectIndex(index);
                return true;
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public void method_25419() {
        syncToServer();
        super.method_25419();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private List<SmartphoneData.PhoneRecord> activeRecords() {
        return showingCalls ? calls : messages;
    }

    private void switchMode(boolean callsMode) {
        if (showingCalls == callsMode) {
            return;
        }
        commitFields();
        showingCalls = callsMode;
        page = 0;
        selected = -1;
        clearFields();
        refreshWidgets();
    }

    private void selectIndex(int index) {
        commitFields();
        selected = index;
        loadSelectedIntoFields();
        refreshWidgets();
    }

    private void changePage(int delta) {
        commitFields();
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(totalPages - 1, page + delta));
        selected = -1;
        clearFields();
        refreshWidgets();
    }

    private void addRecord() {
        commitFields();
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        if (records.size() >= SmartphoneData.MAX_RECORDS) {
            return;
        }
        records.add(new SmartphoneData.PhoneRecord("", "", ""));
        selected = records.size() - 1;
        page = selected / PAGE_SIZE;
        loadSelectedIntoFields();
        refreshWidgets();
        nameField.method_25365(true);
    }

    private void applyRecord() {
        commitFields();
        refreshWidgets();
    }

    private void deleteRecord() {
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        if (selected < 0 || selected >= records.size()) {
            return;
        }
        records.remove(selected);
        selected = -1;
        int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.min(page, totalPages - 1);
        clearFields();
        refreshWidgets();
    }

    private void commitFields() {
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        if (selected < 0 || selected >= records.size() || nameField == null) {
            return;
        }
        records.set(selected, new SmartphoneData.PhoneRecord(
                nameField.method_1882(), detailField.method_1882(), timeField.method_1882()));
    }

    private void loadSelectedIntoFields() {
        if (nameField == null) {
            return;
        }
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        if (selected < 0 || selected >= records.size()) {
            clearFields();
            return;
        }
        SmartphoneData.PhoneRecord record = records.get(selected);
        nameField.method_1852(record.name());
        timeField.method_1852(record.time());
        detailField.method_1852(record.detail());
    }

    private void clearFields() {
        if (nameField != null) {
            nameField.method_1852("");
            timeField.method_1852("");
            detailField.method_1852("");
        }
    }

    private void refreshWidgets() {
        if (callsTab == null) {
            return;
        }

        List<SmartphoneData.PhoneRecord> records = activeRecords();
        int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.min(page, totalPages - 1);

        callsTab.field_22763 = !showingCalls;
        messagesTab.field_22763 = showingCalls;
        previousPage.field_22763 = page > 0;
        nextPage.field_22763 = page + 1 < totalPages;
        addButton.field_22763 = records.size() < SmartphoneData.MAX_RECORDS;
        boolean hasSelection = selected >= 0 && selected < records.size();
        applyButton.field_22763 = hasSelection;
        deleteButton.field_22763 = hasSelection;
        nameField.method_1888(hasSelection);
        timeField.method_1888(hasSelection);
        detailField.method_1888(hasSelection);
    }

    private void syncToServer() {
        if (synced) {
            return;
        }
        commitFields();
        SmartphoneData data = new SmartphoneData(calls, messages);

        if (field_22787 != null && field_22787.field_1724 != null) {
            class_1799 held = field_22787.field_1724.method_5998(hand);
            if (held.method_31574(SmartphoneMod.SMARTPHONE)) {
                data.writeTo(held);
            }
        }

        if (ClientPlayNetworking.canSend(SmartphoneMod.SAVE_PACKET)) {
            class_2540 buf = PacketByteBufs.create();
            buf.method_10817(hand);
            data.writePacket(buf);
            ClientPlayNetworking.send(SmartphoneMod.SAVE_PACKET, buf);
        }
        synced = true;
    }
}
