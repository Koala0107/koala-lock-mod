package kr.koala.korime_scene;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3913;
import net.minecraft.class_3919;
import net.minecraft.server.MinecraftServer;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;

/** Server-side state for the button-based keypad screen. */
public final class KeypadScreenHandler extends class_1703 {
    public static final int MIN_DIGITS = 1;
    public static final int MAX_DIGITS = 8;
    public static final int CLEAR_BUTTON = 10;
    public static final int CONFIRM_BUTTON = 11;

    private final Predicate<String> confirmAction;
    private final StringBuilder input = new StringBuilder(MAX_DIGITS);
    private final class_3913 properties;

    public KeypadScreenHandler(int syncId, class_1661 inventory) {
        this(syncId, inventory, code -> true, new class_3919(1));
    }

    public KeypadScreenHandler(int syncId, class_1661 inventory, Predicate<String> confirmAction) {
        this(syncId, inventory, confirmAction, new class_3919(1));
    }

    private KeypadScreenHandler(int syncId, class_1661 inventory, Predicate<String> confirmAction,
                                class_3913 properties) {
        super(KorimeSceneMod.KEYPAD_SCREEN_HANDLER, syncId);
        this.confirmAction = confirmAction;
        this.properties = properties;
        method_17360(properties);
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id >= 0 && id <= 9) {
            if (input.length() < MAX_DIGITS) input.append(id);
            return true;
        }
        if (id == CLEAR_BUTTON) {
            input.setLength(0);
            return true;
        }
        if (id == CONFIRM_BUTTON && input.length() >= MIN_DIGITS && input.length() <= MAX_DIGITS) {
            int before = keypadCountInHands(player);
            boolean success = confirmAction.test(input.toString());
            int after = keypadCountInHands(player);
            input.setLength(0);

            if (success) {
                boolean setupConsumedKeypad = after < before;
                if (!setupConsumedKeypad && player instanceof class_3222 serverPlayer) {
                    playSuccessChime(serverPlayer);
                }
                if (player instanceof class_3222 serverPlayer) {
                    serverPlayer.method_7346();
                }
            } else {
                properties.method_17391(0, properties.method_17390(0) + 1);
            }
            return true;
        }
        return false;
    }

    private static int keypadCountInHands(class_1657 player) {
        int count = 0;
        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();
        if (main.method_31574(KorimeSceneMod.KEYPAD)) count += main.method_7947();
        if (off.method_31574(KorimeSceneMod.KEYPAD)) count += off.method_7947();
        return count;
    }

    private static void playSuccessChime(class_3222 player) {
        playChimeNote(player, 1.0F);
        scheduleChimeNote(player, 150L, 1.25F);
        scheduleChimeNote(player, 300L, 1.5F);
    }

    private static void scheduleChimeNote(class_3222 player, long delayMillis, float pitch) {
        MinecraftServer server = player.method_5682();
        if (server == null) return;
        CompletableFuture.delayedExecutor(delayMillis, TimeUnit.MILLISECONDS).execute(() ->
                server.execute(() -> {
                    if (!player.method_31481()) playChimeNote(player, pitch);
                }));
    }

    private static void playChimeNote(class_3222 player, float pitch) {
        class_3218 world = player.method_51469();
        world.method_8396(null, player.method_24515(), class_3417.field_14725.comp_349(),
                class_3419.field_15248, 1.15F, pitch);
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {}

    @Override
    public boolean method_7597(class_1657 player) { return true; }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) { return class_1799.field_8037; }

    public int getErrorCounter() { return properties.method_17390(0); }
}
