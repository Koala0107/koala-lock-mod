package kr.koala.korime_scene;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;

/** Compact phone UI. Finalized phones are view-only, like a signed written book. */
public final class SmartphoneScreenV2 extends class_437 {
    private static final int PAGE_SIZE = 4;
    private static final int ROW_HEIGHT = 21;
    private static final int ICON_SIZE = 16;
    private static final int INCOMING_COLOR = 0xFFE05252;
    private static final int OUTGOING_COLOR = 0xFF4B82E8;

    private final class_1268 hand;
    private final boolean editable;
    private final List<SmartphoneData.PhoneRecord> calls;
    private final List<SmartphoneData.PhoneRecord> messages;
    private final String savedTitle;
    private final String savedSubtitle;

    private boolean showingCalls = true;
    private boolean directionOutgoing;
    private int page;
    private int selected = -1;
    private boolean synced;

    private int panelX, panelY, panelWidth, panelHeight, listX, listY, listWidth;
    private class_4185 callsTab, messagesTab, previousPage, nextPage;
    private class_4185 addButton, applyButton, deleteButton, finalizeButton, directionButton;
    private class_342 nameField, timeField, detailField;

    public SmartphoneScreenV2(class_1268 hand, class_1799 stack) { this(hand, SmartphoneData.fromStack(stack), true); }
    public SmartphoneScreenV2(SmartphoneData data) { this(null, data, false); }

    private SmartphoneScreenV2(class_1268 hand, SmartphoneData data, boolean allowEditing) {
        super(class_2561.method_43471("screen.korime_scene.smartphone"));
        this.hand = hand;
        this.editable = allowEditing && !data.finalized();
        this.calls = new ArrayList<>(data.calls());
        this.messages = new ArrayList<>(data.messages());
        this.savedTitle = data.title();
        this.savedSubtitle = data.subtitle();
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(278, field_22789 - 12);
        panelHeight = editable ? Math.min(202, field_22790 - 8) : Math.min(160, field_22790 - 8);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;
        int innerX = panelX + 13;
        int innerWidth = panelWidth - 26;
        listX = innerX;
        listY = panelY + 51;
        listWidth = innerWidth;

        callsTab = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.calls"), b -> switchMode(true))
                .method_46434(innerX, panelY + 31, (innerWidth - 4) / 2, 17).method_46431());
        messagesTab = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.messages"), b -> switchMode(false))
                .method_46434(innerX + (innerWidth + 4) / 2, panelY + 31, (innerWidth - 4) / 2, 17).method_46431());

        int pageY = panelY + 137;
        previousPage = method_37063(class_4185.method_46430(class_2561.method_43470("‹"), b -> changePage(-1)).method_46434(innerX, pageY, 24, 16).method_46431());
        nextPage = method_37063(class_4185.method_46430(class_2561.method_43470("›"), b -> changePage(1)).method_46434(innerX + innerWidth - 24, pageY, 24, 16).method_46431());

        if (editable) {
            int fieldsY = panelY + 157;
            directionButton = method_37063(class_4185.method_46430(directionText(), b -> toggleDirection())
                    .method_46434(innerX, fieldsY, 45, 18).method_46431());
            nameField = method_37063(new class_342(field_22793, innerX + 48, fieldsY, 62, 18,
                    class_2561.method_43471("screen.korime_scene.smartphone.name")));
            nameField.method_1880(SmartphoneData.MAX_NAME_LENGTH);
            nameField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.name"));
            timeField = method_37063(new class_342(field_22793, innerX + 113, fieldsY, 47, 18,
                    class_2561.method_43471("screen.korime_scene.smartphone.time")));
            timeField.method_1880(SmartphoneData.MAX_TIME_LENGTH);
            timeField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.time"));
            detailField = method_37063(new class_342(field_22793, innerX + 163, fieldsY, innerWidth - 163, 18,
                    class_2561.method_43471("screen.korime_scene.smartphone.detail")));
            detailField.method_1880(SmartphoneData.MAX_DETAIL_LENGTH);
            detailField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.detail"));

            int buttonY = panelY + 180;
            int gap = 3;
            int buttonWidth = (innerWidth - gap * 3) / 4;
            addButton = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.add"), b -> addRecord())
                    .method_46434(innerX, buttonY, buttonWidth, 16).method_46431());
            applyButton = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.apply"), b -> applyRecord())
                    .method_46434(innerX + buttonWidth + gap, buttonY, buttonWidth, 16).method_46431());
            deleteButton = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.delete"), b -> deleteRecord())
                    .method_46434(innerX + (buttonWidth + gap) * 2, buttonY, buttonWidth, 16).method_46431());
            finalizeButton = method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.smartphone.finalize"), b -> finalizePhone())
                    .method_46434(innerX + (buttonWidth + gap) * 3, buttonY, innerWidth - (buttonWidth + gap) * 3, 16).method_46431());
        }
        loadSelectedIntoFields();
        refreshWidgets();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Intentionally no-op: the phone UI should not dim the world behind it.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        drawPhoneChrome(context);
        drawRecordList(context, mouseX, mouseY);
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        context.method_27534(field_22793,
                class_2561.method_43469("screen.korime_scene.smartphone.page", page + 1, totalPages, records.size()),
                panelX + panelWidth / 2, panelY + 141, 0xFF58616A);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    private void drawPhoneChrome(class_332 context) {
        context.method_25294(panelX - 5, panelY - 4, panelX + panelWidth + 5, panelY + panelHeight + 5, 0x66000000);
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF050709);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF171D22);
        context.method_25294(panelX + 6, panelY + 6, panelX + panelWidth - 6, panelY + panelHeight - 6, 0xFFF4F4F4);
        context.method_25294(panelX + 7, panelY + 7, panelX + panelWidth - 7, panelY + 28, 0xFF28333D);
        int iconColor = showingCalls ? 0xFF2FB55D : 0xFF318BEA;
        drawModeIcon(context, panelX + 13, panelY + 9, ICON_SIZE, showingCalls, iconColor);
        context.method_27535(field_22793,
                showingCalls ? class_2561.method_43471("screen.korime_scene.smartphone.calls") : class_2561.method_43471("screen.korime_scene.smartphone.messages"),
                panelX + 35, panelY + 12, 0xFFFFFFFF);
        context.method_25294(panelX + 9, panelY + 49, panelX + panelWidth - 9, panelY + 136, 0xFFFFFFFF);
        context.method_25294(panelX + 9, panelY + 49, panelX + panelWidth - 9, panelY + 50, 0xFFD0D4D8);
        context.method_25294(panelX + 9, panelY + 135, panelX + panelWidth - 9, panelY + 136, 0xFFD0D4D8);
        context.method_25294(panelX + panelWidth / 2 - 21, panelY + panelHeight - 4, panelX + panelWidth / 2 + 21, panelY + panelHeight - 2, 0xFF8B949C);
    }

    private void drawRecordList(class_332 context, int mouseX, int mouseY) {
        List<SmartphoneData.PhoneRecord> records = activeRecords();
        for (int row = 0; row < PAGE_SIZE; row++) {
            int index = page * PAGE_SIZE + row;
            int y = listY + row * ROW_HEIGHT;
            boolean hovered = mouseX >= listX && mouseX < listX + listWidth && mouseY >= y && mouseY < y + ROW_HEIGHT;
            boolean isSelected = editable && index == selected;
            if (hovered || isSelected) context.method_25294(listX, y, listX + listWidth, y + ROW_HEIGHT, isSelected ? 0xFFE3F0FB : 0xFFF1F4F6);
            if (row > 0) context.method_25294(listX + 25, y, listX + listWidth, y + 1, 0xFFE1E4E7);
            if (index >= records.size()) continue;

            SmartphoneData.PhoneRecord record = records.get(index);
            String name = record.name().isBlank() ? class_2561.method_43471("screen.korime_scene.smartphone.unnamed").getString() : record.name();
            String time = record.time().isBlank() ? "--:--" : record.time();
            String detail = record.detail().isBlank() ? "..." : record.detail();
            drawAvatar(context, listX + 4, y + 2, index);
            int textX = listX + 25;
            int timeWidth = field_22793.method_1727(time);
            context.method_51439(field_22793, class_2561.method_43470(field_22793.method_27523(name, listWidth - 82)), textX, y + 2, 0xFF1F252B, false);
            context.method_51439(field_22793, class_2561.method_43470(time), listX + listWidth - timeWidth - 4, y + 2, 0xFF6C747B, false);
            String dir = directionText(record.outgoing()).getString();
            String secondary = dir + " · " + field_22793.method_27523(detail, listWidth - 58);
            int color = record.outgoing() ? OUTGOING_COLOR : INCOMING_COLOR;
            context.method_51439(field_22793, class_2561.method_43470(secondary), textX, y + 11, color, false);
        }
    }

    private void drawAvatar(class_332 context, int x, int y, int index) {
        int[] palette = {0xFFBA704A,0xFF6AA6D8,0xFF63A875,0xFF9A7AC2,0xFFC09048,0xFF70767C};
        drawModeIcon(context, x, y, ICON_SIZE, showingCalls, palette[Math.floorMod(index, palette.length)]);
    }

    private void drawModeIcon(class_332 context, int x, int y, int size, boolean callMode, int background) {
        context.method_25294(x, y, x + size, y + size, background);
        int white = 0xFFFFFFFF;
        int pad = 3;
        if (callMode) {
            context.method_25294(x + pad, y + pad, x + pad + 3, y + 8, white);
            context.method_25294(x + 6, y + 7, x + 11, y + 10, white);
            context.method_25294(x + 10, y + 7, x + 13, y + 13, white);
        } else {
            context.method_25294(x + pad, y + 4, x + size - pad, y + 11, white);
            context.method_25294(x + 5, y + 11, x + 8, y + 14, white);
        }
    }

    private class_2561 directionText() { return coloredDirectionText(directionOutgoing); }
    private class_2561 coloredDirectionText(boolean outgoing) {
        return directionText(outgoing).method_27661().method_27694(style -> style.method_36139(outgoing ? 0x4B82E8 : 0xE05252));
    }
    private class_2561 directionText(boolean outgoing) {
        if (showingCalls) return class_2561.method_43471(outgoing ? "screen.korime_scene.smartphone.call_outgoing" : "screen.korime_scene.smartphone.call_incoming");
        return class_2561.method_43471(outgoing ? "screen.korime_scene.smartphone.message_outgoing" : "screen.korime_scene.smartphone.message_incoming");
    }
    private void toggleDirection() {
        if (!editable || selected < 0) return;
        directionOutgoing = !directionOutgoing;
        directionButton.method_25355(directionText());
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (editable && button == 0 && mouseX >= listX && mouseX < listX + listWidth && mouseY >= listY && mouseY < listY + PAGE_SIZE * ROW_HEIGHT) {
            int index = page * PAGE_SIZE + class_3532.method_15357((mouseY - listY) / ROW_HEIGHT);
            if (index < activeRecords().size()) { selectIndex(index); return true; }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override public void method_25419() { super.method_25419(); }
    @Override public boolean method_25421() { return false; }
    private List<SmartphoneData.PhoneRecord> activeRecords() { return showingCalls ? calls : messages; }

    private void switchMode(boolean callsMode) {
        if (showingCalls == callsMode) return;
        commitFields(); showingCalls = callsMode; page = 0; selected = -1; clearFields(); refreshWidgets();
    }
    private void selectIndex(int index) { commitFields(); selected = index; loadSelectedIntoFields(); refreshWidgets(); }
    private void changePage(int delta) {
        commitFields();
        int totalPages = Math.max(1, (activeRecords().size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(totalPages - 1, page + delta)); selected = -1; clearFields(); refreshWidgets();
    }
    private void addRecord() {
        if (!editable) return;
        commitFields(); List<SmartphoneData.PhoneRecord> records = activeRecords();
        if (records.size() >= SmartphoneData.MAX_RECORDS) return;
        records.add(new SmartphoneData.PhoneRecord("", "", "", false)); selected = records.size() - 1; page = selected / PAGE_SIZE;
        loadSelectedIntoFields(); refreshWidgets(); nameField.method_25365(true);
    }
    private void applyRecord() { commitFields(); refreshWidgets(); }
    private void deleteRecord() {
        if (!editable) return;
        List<SmartphoneData.PhoneRecord> records = activeRecords(); if (selected < 0 || selected >= records.size()) return;
        records.remove(selected); selected = -1; page = Math.min(page, Math.max(0, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE - 1)); clearFields(); refreshWidgets();
    }
    private void finalizePhone() {
        if (!editable || synced || hand == null || field_22787 == null) return;
        commitFields();
        String title = savedTitle.isBlank() ? class_2561.method_43471("screen.korime_scene.smartphone.save.default_name").getString() : savedTitle;
        String subtitle = savedSubtitle.isBlank() ? class_2561.method_43471("screen.korime_scene.smartphone.save.default_subtitle").getString() : savedSubtitle;
        field_22787.method_1507(new SmartphoneFinalizeScreen(this, title, subtitle));
    }

    void finalizeWithMetadata(String title, String subtitle) {
        if (!editable || synced || hand == null) return;
        commitFields(); SmartphoneData data = new SmartphoneData(calls, messages, true, title, subtitle);
        if (field_22787 != null && field_22787.field_1724 != null) {
            class_1799 held = field_22787.field_1724.method_5998(hand);
            if (held.method_31574(SmartphoneMod.SMARTPHONE) && !SmartphoneData.fromStack(held).finalized()) data.writeTo(held);
        }
        if (ClientPlayNetworking.canSend(SmartphoneMod.SAVE_PACKET)) {
            class_2540 buf = PacketByteBufs.create(); buf.method_10817(hand); data.writePacket(buf); ClientPlayNetworking.send(SmartphoneMod.SAVE_PACKET, buf);
        }
        synced = true; if (field_22787 != null) field_22787.method_1507(null);
    }

    private void commitFields() {
        if (!editable || nameField == null) return;
        List<SmartphoneData.PhoneRecord> records = activeRecords(); if (selected < 0 || selected >= records.size()) return;
        records.set(selected, new SmartphoneData.PhoneRecord(nameField.method_1882(), detailField.method_1882(), timeField.method_1882(), directionOutgoing));
    }
    private void loadSelectedIntoFields() {
        if (!editable || nameField == null) return;
        List<SmartphoneData.PhoneRecord> records = activeRecords(); if (selected < 0 || selected >= records.size()) { clearFields(); return; }
        SmartphoneData.PhoneRecord record = records.get(selected);
        nameField.method_1852(record.name()); timeField.method_1852(record.time()); detailField.method_1852(record.detail()); directionOutgoing = record.outgoing();
        directionButton.method_25355(directionText());
    }
    private void clearFields() {
        directionOutgoing = false;
        if (nameField != null) { nameField.method_1852(""); timeField.method_1852(""); detailField.method_1852(""); }
        if (directionButton != null) directionButton.method_25355(directionText());
    }
    private void refreshWidgets() {
        if (callsTab == null) return;
        List<SmartphoneData.PhoneRecord> records = activeRecords(); int totalPages = Math.max(1, (records.size() + PAGE_SIZE - 1) / PAGE_SIZE); page = Math.min(page, totalPages - 1);
        callsTab.field_22763 = !showingCalls; messagesTab.field_22763 = showingCalls; previousPage.field_22763 = page > 0; nextPage.field_22763 = page + 1 < totalPages;
        if (editable) {
            addButton.field_22763 = records.size() < SmartphoneData.MAX_RECORDS;
            boolean hasSelection = selected >= 0 && selected < records.size();
            applyButton.field_22763 = hasSelection; deleteButton.field_22763 = hasSelection; directionButton.field_22763 = hasSelection;
            nameField.method_1888(hasSelection); timeField.method_1888(hasSelection); detailField.method_1888(hasSelection); finalizeButton.field_22763 = true;
            directionButton.method_25355(directionText());
        }
    }
}