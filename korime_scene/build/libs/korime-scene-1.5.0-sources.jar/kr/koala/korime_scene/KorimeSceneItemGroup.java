package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public final class KorimeSceneItemGroup implements ModInitializer {
    public static final class_1761 GROUP = class_2378.method_10230(
            class_7923.field_44687,
            new class_2960(KorimeSceneMod.MOD_ID, "korime_scene"),
            FabricItemGroup.builder()
                    .method_47321(class_2561.method_43471("itemGroup.korime_scene.korime_scene"))
                    .method_47320(() -> new class_1799(SmartphoneMod.SMARTPHONE))
                    .method_47317((context, entries) -> {
                        entries.method_45421(KorimeSceneMod.LOCK_KEY);
                        entries.method_45421(KorimeSceneMod.KEYPAD);
                        entries.method_45421(SmartphoneMod.SMARTPHONE);
                        for (var item : EvidenceMarkerMod.ITEMS) entries.method_45421(item);
                        entries.method_45421(DetectiveItemsMod.DETECTIVE_HELMET);
                        entries.method_45421(DetectiveItemsMod.DETECTIVE_CHESTPLATE);
                        entries.method_45421(DetectiveItemsMod.MAGNIFYING_GLASS);
                        entries.method_45421(DetectiveItemsMod.INVESTIGATION_BOARD);
                        entries.method_45421(SceneToolsMod.CCTV_ITEM);
                        entries.method_45421(SceneToolsMod.ITEM_EDITOR_ITEM);
                        entries.method_45421(SceneToolsMod.EVIDENCE_MAGNIFIER_ITEM);
                    })
                    .method_47324());

    @Override public void onInitialize() { }
}
