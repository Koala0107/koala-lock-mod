package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.minecraft.class_1738;
import net.minecraft.class_1740;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4970;
import net.minecraft.class_7923;

public final class DetectiveItemsMod implements ModInitializer {
    public static final class_1792 DETECTIVE_HELMET = class_2378.method_10230(
            class_7923.field_41178, new class_2960(KorimeSceneMod.MOD_ID, "detective_helmet"),
            new class_1738(class_1740.field_7892, class_1738.class_8051.field_41934, new class_1792.class_1793()));

    public static final class_1792 DETECTIVE_CHESTPLATE = class_2378.method_10230(
            class_7923.field_41178, new class_2960(KorimeSceneMod.MOD_ID, "detective_chestplate"),
            new class_1738(class_1740.field_7892, class_1738.class_8051.field_41935, new class_1792.class_1793()));

    public static final class_2960 MAGNIFYING_GLASS_USE_ID =
            new class_2960(KorimeSceneMod.MOD_ID, "magnifying_glass_use");
    public static final class_3414 MAGNIFYING_GLASS_USE = class_2378.method_10230(
            class_7923.field_41172,
            MAGNIFYING_GLASS_USE_ID,
            class_3414.method_47908(MAGNIFYING_GLASS_USE_ID));

    public static final class_2248 MAGNIFYING_GLASS_BLOCK = class_2378.method_10230(
            class_7923.field_41175, new class_2960(KorimeSceneMod.MOD_ID, "magnifying_glass"),
            new MagnifyingGlassBlock(class_4970.class_2251.method_9637().method_9632(0.15F)
                    .method_22488().method_9626(class_2498.field_11533)));

    public static final class_1792 MAGNIFYING_GLASS = class_2378.method_10230(
            class_7923.field_41178, new class_2960(KorimeSceneMod.MOD_ID, "magnifying_glass"),
            new MagnifyingGlassItem(MAGNIFYING_GLASS_BLOCK, new class_1792.class_1793().method_7889(16)));

    public static final class_2248 INVESTIGATION_BOARD_BLOCK = class_2378.method_10230(
            class_7923.field_41175, new class_2960(KorimeSceneMod.MOD_ID, "investigation_board"),
            new InvestigationBoardBlock(class_4970.class_2251.method_9637().method_9632(0.25F)
                    .method_22488().method_9626(class_2498.field_11547)));

    public static final class_1792 INVESTIGATION_BOARD = class_2378.method_10230(
            class_7923.field_41178, new class_2960(KorimeSceneMod.MOD_ID, "investigation_board"),
            new class_1747(INVESTIGATION_BOARD_BLOCK, new class_1792.class_1793().method_7889(16)));

    @Override public void onInitialize() { }
}
