package kr.koala.korime_scene;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public final class SmartphoneBlockEntity extends class_2586 {
    private static final String ITEM_NBT_KEY = "PhoneItemNbt";
    private SmartphoneData data = SmartphoneData.empty();

    public SmartphoneBlockEntity(class_2338 pos, class_2680 state) {
        super(SmartphoneMod.SMARTPHONE_BLOCK_ENTITY, pos, state);
    }

    public SmartphoneData getData() {
        return data;
    }

    public void setData(SmartphoneData data) {
        this.data = new SmartphoneData(data.calls(), data.messages(), data.finalized(),
                data.title(), data.subtitle());
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14178().method_14128(field_11867);
        }
    }

    public class_1799 createPhoneStack() {
        class_1799 stack = new class_1799(SmartphoneMod.SMARTPHONE);
        data.writeTo(stack);
        return stack;
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_1799 temp = new class_1799(SmartphoneMod.SMARTPHONE);
        data.writeTo(temp);
        if (temp.method_7969() != null) {
            nbt.method_10566(ITEM_NBT_KEY, temp.method_7969().method_10553());
        }
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        if (nbt.method_10573(ITEM_NBT_KEY, class_2520.field_33260)) {
            class_1799 temp = new class_1799(SmartphoneMod.SMARTPHONE);
            temp.method_7980(nbt.method_10562(ITEM_NBT_KEY).method_10553());
            data = SmartphoneData.fromStack(temp);
        } else {
            data = SmartphoneData.empty();
        }
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}
