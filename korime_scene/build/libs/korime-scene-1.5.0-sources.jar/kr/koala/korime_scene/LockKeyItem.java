package kr.koala.korime_scene;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2520;

public final class LockKeyItem extends class_1792 {
    private static final String KEY_ID_NBT = "KorimeSceneKeyId";

    public LockKeyItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public boolean method_7886(class_1799 stack) {
        return getKeyId(stack).isPresent() || super.method_7886(stack);
    }

    public static UUID getOrCreateKeyId(class_1799 stack) {
        Optional<UUID> current = getKeyId(stack);
        if (current.isPresent()) {
            return current.get();
        }

        UUID created = UUID.randomUUID();
        stack.method_7948().method_10582(KEY_ID_NBT, created.toString());
        return created;
    }

    public static Optional<UUID> getKeyId(class_1799 stack) {
        if (!stack.method_31574(KorimeSceneMod.LOCK_KEY) || !stack.method_7985()) {
            return Optional.empty();
        }

        String raw = stack.method_7969().method_10558(KEY_ID_NBT);
        if (raw.isBlank() || !stack.method_7969().method_10573(KEY_ID_NBT, class_2520.field_33258)) {
            return Optional.empty();
        }

        try {
            return Optional.of(UUID.fromString(raw));
        } catch (IllegalArgumentException ignored) {
            return Optional.empty();
        }
    }
}
