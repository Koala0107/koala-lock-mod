package kr.koala.korime_scene;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class ItemEditorScreen extends class_437 {
    private final class_2338 editorPos;
    private final class_1799 previewStack;
    private class_342 nameField;
    private class_342 descriptionField;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    public ItemEditorScreen(class_2338 editorPos, class_1799 previewStack) {
        super(class_2561.method_43471("screen.korime_scene.item_editor.title"));
        this.editorPos = editorPos.method_10062();
        this.previewStack = previewStack;
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(310, field_22789 - 20);
        panelHeight = Math.min(190, field_22790 - 20);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;
        int innerX = panelX + 56;
        int innerWidth = panelWidth - 72;

        nameField = method_37063(new class_342(field_22793,
                innerX, panelY + 55, innerWidth, 20,
                class_2561.method_43471("screen.korime_scene.item_editor.name")));
        nameField.method_1880(128);
        nameField.method_47404(class_2561.method_43471("screen.korime_scene.item_editor.name_placeholder"));
        if (!previewStack.method_7960() && previewStack.method_7938()) nameField.method_1852(previewStack.method_7964().getString());

        descriptionField = method_37063(new class_342(field_22793,
                innerX, panelY + 96, innerWidth, 20,
                class_2561.method_43471("screen.korime_scene.item_editor.description")));
        descriptionField.method_1880(512);
        descriptionField.method_1868(0xB45CFF);
        descriptionField.method_1860(0xB45CFF);
        descriptionField.method_47404(class_2561.method_43471("screen.korime_scene.item_editor.description_placeholder")
                .method_27661().method_27694(style -> style.method_36139(0xB45CFF)));
        descriptionField.method_1852(readFirstLore(previewStack));

        int gap = 8;
        int buttonWidth = (innerWidth - gap) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> method_25419())
                .method_46434(innerX, panelY + 145, buttonWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.item_editor.apply"), button -> apply())
                .method_46434(innerX + buttonWidth + gap, panelY + 145, buttonWidth, 20).method_46431());

        nameField.method_25365(true);
    }

    private static String readFirstLore(class_1799 stack) {
        if (stack.method_7960() || stack.method_7969() == null) return "";
        class_2487 root = stack.method_7969();
        if (!root.method_10573("display", class_2520.field_33260)) return "";
        class_2487 display = root.method_10562("display");
        if (!display.method_10573("Lore", class_2520.field_33259)) return "";
        class_2499 lore = display.method_10554("Lore", class_2520.field_33258);
        if (lore.isEmpty()) return "";
        try {
            JsonObject obj = JsonParser.parseString(lore.method_10608(0)).getAsJsonObject();
            return obj.has("text") ? obj.get("text").getAsString() : "";
        } catch (RuntimeException ignored) {
            return "";
        }
    }

    private void apply() {
        if (previewStack.method_7960()) return;
        class_2540 buf = PacketByteBufs.create();
        buf.method_10807(editorPos);
        buf.method_10788(nameField.method_1882(), 128);
        buf.method_10788(descriptionField.method_1882(), 512);
        ClientPlayNetworking.send(SceneToolsMod.EDIT_ITEM_PACKET, buf);
        method_25419();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Keep the world visible, like the smartphone editor.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF080A0D);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFECE8F1);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + 30, 0xFF2B2430);

        context.method_27534(field_22793, field_22785, panelX + panelWidth / 2, panelY + 11, 0xFFFFFFFF);
        context.method_25294(panelX + 14, panelY + 48, panelX + 48, panelY + 82, 0xFFB9B1C0);
        if (!previewStack.method_7960()) context.method_51427(previewStack, panelX + 23, panelY + 57);

        context.method_51439(field_22793, class_2561.method_43471("screen.korime_scene.item_editor.name"), panelX + 56, panelY + 43, 0xFF39333D, false);
        context.method_51439(field_22793, class_2561.method_43471("screen.korime_scene.item_editor.description"), panelX + 56, panelY + 84, 0xFF9B59D0, false);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
