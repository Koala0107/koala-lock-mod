package kr.koala.korime_scene;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public final class CctvBlockEntity extends class_2586 {
    public static final int MAX_RECORDS = 64;
    public static final int MAX_RECORD_LENGTH = 512;

    private final List<String> records = new ArrayList<>();
    private boolean finalized;

    public CctvBlockEntity(class_2338 pos, class_2680 state) {
        super(SceneToolsMod.CCTV_BLOCK_ENTITY, pos, state);
    }

    public List<String> getRecords() {
        return List.copyOf(records);
    }

    public boolean isFinalized() {
        return finalized;
    }

    public void setEvidence(List<String> newRecords, boolean finalize) {
        if (finalized) return;

        records.clear();
        for (String line : newRecords) {
            String clean = line == null ? "" : line.trim();
            if (clean.isEmpty()) continue;
            if (clean.length() > MAX_RECORD_LENGTH) clean = clean.substring(0, MAX_RECORD_LENGTH);
            records.add(clean);
            if (records.size() >= MAX_RECORDS) break;
        }
        finalized = finalize;
        sync();
    }

    private void sync() {
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14178().method_14128(field_11867);
        }
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        class_2499 list = new class_2499();
        for (String record : records) list.add(class_2519.method_23256(record));
        nbt.method_10566("Records", list);
        nbt.method_10556("Finalized", finalized);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        records.clear();
        if (nbt.method_10573("Records", class_2520.field_33259)) {
            class_2499 list = nbt.method_10554("Records", class_2520.field_33258);
            for (int i = 0; i < list.size() && records.size() < MAX_RECORDS; i++) {
                String line = list.method_10608(i);
                if (line.length() > MAX_RECORD_LENGTH) line = line.substring(0, MAX_RECORD_LENGTH);
                records.add(line);
            }
        }
        finalized = nbt.method_10577("Finalized");
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }
}
