package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2281;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2494;
import net.minecraft.class_2499;
import net.minecraft.class_2533;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3708;
import net.minecraft.class_3917;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_747;
import net.minecraft.class_7701;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_8113;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class KorimeSceneMod implements ModInitializer {
    public static final String MOD_ID = "korime_scene";
    public static final String KEY_LOCK = "key";
    public static final String KEYPAD_LOCK = "keypad";
    public static final String MARKER_TAG = MOD_ID + ":marker";
    public static final String MARKER_LAYOUT_TAG = MOD_ID + ":marker_layout_v2";

    private static final ConcurrentLinkedQueue<Runnable> END_OF_TICK_ACTIONS = new ConcurrentLinkedQueue<>();

    public static final class_1792 LOCK_KEY = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(MOD_ID, "key"),
            new LockKeyItem(new class_1792.class_1793().method_7889(1))
    );

    public static final class_1792 KEYPAD = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(MOD_ID, "keypad"),
            new class_1792(new class_1792.class_1793().method_7889(16))
    );

    public static final class_3917<KeypadScreenHandler> KEYPAD_SCREEN_HANDLER = class_2378.method_10230(
            class_7923.field_41187,
            new class_2960(MOD_ID, "keypad"),
            new class_3917<>(KeypadScreenHandler::new, class_7701.field_40182)
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> {
            entries.method_45421(LOCK_KEY);
            entries.method_45421(KEYPAD);
        });
        UseBlockCallback.EVENT.register(KorimeSceneMod::onUseBlock);
        AttackEntityCallback.EVENT.register(KorimeSceneMod::onAttackEntity);
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof class_3218 serverWorld) {
                LockState lockState = LockState.get(serverWorld);
                findExistingLock(lockState, linkedPositions(serverWorld, pos, state)).ifPresent(lock -> {
                    lockState.removeLock(lock.lockId());
                    removeLockMarkers(serverWorld, pos, lock.lockId());
                });
            }
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.method_8510() % 20 == 0) {
                LockState lockState = LockState.get(world);
                for (LockState.RemovedLock removed : lockState.pruneInvalid(world)) {
                    removeLockMarkers(world, removed.pos(), removed.lockId());
                }
                syncLockMarkers(world);
            }
        });
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Runnable action;
            while ((action = END_OF_TICK_ACTIONS.poll()) != null) {
                action.run();
            }
        });
    }

    private static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
        if (world.field_9236 || !(world instanceof class_3218 serverWorld)
                || !(player instanceof class_3222 serverPlayer)) {
            return class_1269.field_5811;
        }

        class_2338 clickedPos = hit.method_17777();
        class_2680 clickedState = serverWorld.method_8320(clickedPos);
        if (!isLockable(serverWorld, clickedPos, clickedState)) {
            return class_1269.field_5811;
        }

        List<class_2338> linkedPositions = linkedPositions(serverWorld, clickedPos, clickedState);
        LockState lockState = LockState.get(serverWorld);
        Optional<LockState.LockEntry> existing = findExistingLock(lockState, linkedPositions);
        class_1799 heldStack = player.method_5998(hand);

        if (existing.isPresent() && KEYPAD_LOCK.equals(existing.get().type())) {
            openKeypadUnlock(serverPlayer, serverWorld, hand, hit, existing.get(), player.method_5715());
            return class_1269.field_5812;
        }

        if (player.method_5715() && existing.isEmpty() && heldStack.method_31574(KEYPAD)) {
            openKeypadSetup(serverPlayer, serverWorld, hand, linkedPositions);
            return class_1269.field_5812;
        }

        if (player.method_5715()) {
            if (!heldStack.method_31574(LOCK_KEY)) {
                if (existing.isPresent()) {
                    send(player, "message.korime_scene.wrong_key");
                    return class_1269.field_5814;
                }
                return class_1269.field_5811;
            }

            if (existing.isEmpty()) {
                if (LockKeyItem.getKeyId(heldStack).isPresent()) {
                    send(player, "message.korime_scene.key_already_assigned");
                    return class_1269.field_5814;
                }
                UUID heldKeyId = LockKeyItem.getOrCreateKeyId(heldStack);
                UUID lockId = UUID.randomUUID();
                putLinkedLock(serverWorld, linkedPositions,
                        new LockState.LockEntry(KEY_LOCK, heldKeyId.toString(), lockId,
                                player.method_5667(), ""));
                send(player, "message.korime_scene.locked");
                return class_1269.field_5812;
            }

            if (keyMatches(heldStack, existing.get())) {
                lockState.removeLock(existing.get().lockId());
                removeLockMarkers(serverWorld, clickedPos, existing.get().lockId());
                send(player, "message.korime_scene.unlocked");
                return class_1269.field_5812;
            }

            send(player, "message.korime_scene.wrong_key");
            return class_1269.field_5814;
        }

        if (existing.isEmpty() || keyMatches(heldStack, existing.get())) {
            return class_1269.field_5811;
        }

        send(player, "message.korime_scene.locked_need_key");
        return class_1269.field_5814;
    }

    private static void openKeypadSetup(class_3222 player, class_3218 world, class_1268 hand,
                                        List<class_2338> linkedPositions) {
        player.method_17355(new class_747(
                (syncId, inventory, ignored) -> new KeypadScreenHandler(syncId, inventory, code -> {
                    LockState lockState = LockState.get(world);
                    if (findExistingLock(lockState, linkedPositions).isPresent()) {
                        send(player, "message.korime_scene.already_locked");
                        return false;
                    }

                    for (class_2338 pos : linkedPositions) {
                        class_2680 state = world.method_8320(pos);
                        if (!isLockable(world, pos, state)) {
                            send(player, "message.korime_scene.target_changed");
                            return false;
                        }
                    }

                    class_1799 keypadStack = player.method_5998(hand);
                    if (!keypadStack.method_31574(KEYPAD) && !player.method_31549().field_7477) {
                        send(player, "message.korime_scene.need_keypad");
                        return false;
                    }

                    UUID lockId = UUID.randomUUID();
                    putLinkedLock(world, linkedPositions,
                            new LockState.LockEntry(KEYPAD_LOCK, hashCode(lockId, code), lockId,
                                    player.method_5667(), ""));
                    if (!player.method_31549().field_7477) {
                        keypadStack.method_7934(1);
                    }
                    send(player, "message.korime_scene.keypad_locked");
                    return true;
                }),
                class_2561.method_43471("screen.korime_scene.set_code")
        ));
    }

    private static void openKeypadUnlock(class_3222 player, class_3218 world, class_1268 hand,
                                         class_3965 hit, LockState.LockEntry originalLock,
                                         boolean removeLock) {
        player.method_17355(new class_747(
                (syncId, inventory, ignored) -> new KeypadScreenHandler(syncId, inventory, code -> {
                    LockState lockState = LockState.get(world);
                    Optional<LockState.LockEntry> current = lockState.get(hit.method_17777());
                    if (current.isEmpty() || !current.get().lockId().equals(originalLock.lockId())) {
                        send(player, "message.korime_scene.target_changed");
                        return true;
                    }

                    if (!current.get().credential().equals(hashCode(current.get().lockId(), code))) {
                        send(player, "message.korime_scene.wrong_code");
                        return false;
                    }

                    if (removeLock) {
                        lockState.removeLock(current.get().lockId());
                        removeLockMarkers(world, hit.method_17777(), current.get().lockId());
                        send(player, "message.korime_scene.unlocked");
                    } else {
                        END_OF_TICK_ACTIONS.add(() -> {
                            if (player.method_31481()) {
                                return;
                            }
                            class_2680 targetState = world.method_8320(hit.method_17777());
                            if (isLockable(world, hit.method_17777(), targetState)) {
                                targetState.method_26174(world, player, hand, hit);
                            }
                        });
                    }
                    return true;
                }),
                class_2561.method_43471(removeLock
                        ? "screen.korime_scene.remove_code"
                        : "screen.korime_scene.enter_code")
        ));
    }

    private static void putLinkedLock(class_3218 world, List<class_2338> positions, LockState.LockEntry prototype) {
        LockState state = LockState.get(world);
        for (class_2338 pos : positions) {
            class_2248 block = world.method_8320(pos).method_26204();
            String blockId = class_7923.field_41175.method_10221(block).toString();
            state.put(pos, new LockState.LockEntry(prototype.type(), prototype.credential(),
                    prototype.lockId(), prototype.ownerId(), blockId));
        }
        if (!positions.isEmpty()) {
            spawnLockMarker(world, positions.get(0), prototype);
        }
    }

    private static class_1269 onAttackEntity(class_1657 player, class_1937 world, class_1268 hand,
                                               class_1297 entity, class_3966 hitResult) {
        if (!entity.method_5752().contains(MARKER_TAG)) {
            return class_1269.field_5811;
        }

        if (world.field_9236 || !(world instanceof class_3218 serverWorld)) {
            return class_1269.field_5812;
        }

        Optional<UUID> lockId = markerLockId(entity);
        if (lockId.isPresent()) {
            LockState.get(serverWorld).removeLock(lockId.get());
            entity.method_31472();
            send(player, "message.korime_scene.lock_destroyed");
            return class_1269.field_5812;
        }
        return class_1269.field_5814;
    }

    static boolean isLockable(class_1937 world, class_2338 pos, class_2680 state) {
        class_2248 block = state.method_26204();
        return block instanceof class_2281
                || block instanceof class_3708
                || block instanceof class_2323
                || block instanceof class_2533;
    }

    private static List<class_2338> linkedPositions(class_3218 world, class_2338 pos, class_2680 state) {
        Set<class_2338> positions = new LinkedHashSet<>();
        positions.add(pos.method_10062());

        if (state.method_26204() instanceof class_2323 && state.method_28498(class_2741.field_12533)) {
            class_2338 otherHalf = state.method_11654(class_2741.field_12533).method_15434().equals("upper")
                    ? pos.method_10074()
                    : pos.method_10084();
            if (world.method_8320(otherHalf).method_27852(state.method_26204())) {
                positions.add(otherHalf.method_10062());
            }
        }

        if (state.method_28498(class_2741.field_12506) && state.method_11654(class_2741.field_12506) != class_2745.field_12569) {
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                class_2338 neighbor = pos.method_10093(direction);
                class_2680 neighborState = world.method_8320(neighbor);
                if (neighborState.method_27852(state.method_26204())
                        && neighborState.method_28498(class_2741.field_12506)
                        && neighborState.method_11654(class_2741.field_12506) != class_2745.field_12569) {
                    positions.add(neighbor.method_10062());
                }
            }
        }

        return new ArrayList<>(positions);
    }

    private static Optional<LockState.LockEntry> findExistingLock(LockState state, List<class_2338> positions) {
        for (class_2338 pos : positions) {
            Optional<LockState.LockEntry> lock = state.get(pos);
            if (lock.isPresent()) {
                return lock;
            }
        }
        return Optional.empty();
    }

    private static boolean keyMatches(class_1799 stack, LockState.LockEntry lock) {
        if (!KEY_LOCK.equals(lock.type())) {
            return false;
        }
        return LockKeyItem.getKeyId(stack)
                .map(id -> id.toString().equals(lock.credential()))
                .orElse(false);
    }

    private static String hashCode(UUID lockId, String code) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest((lockId + ":" + code).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hashed);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is not available", exception);
        }
    }

    private static void spawnLockMarker(class_3218 world, class_2338 pos, LockState.LockEntry lock) {
        removeLockMarkers(world, pos, lock.lockId());
        class_243 markerPos = markerPosition(world, pos);
        class_1799 stack = new class_1799(KEYPAD_LOCK.equals(lock.type()) ? KEYPAD : LOCK_KEY);
        stack.method_7977(class_2561.method_43471(KEYPAD_LOCK.equals(lock.type())
                ? "item.korime_scene.keypad_lock.marker"
                : "item.korime_scene.lock_key.marker"));
        stack.method_7948().method_10582("KorimeSceneLockId", lock.lockId().toString());
        class_8113.class_8122 marker = new class_8113.class_8122(class_1299.field_42456, world);
        class_2487 displaySettings = new class_2487();
        displaySettings.method_10582("billboard", "center");
        displaySettings.method_10582("item_display", "fixed");
        displaySettings.method_10548("width", 0.30F);
        displaySettings.method_10548("height", 0.38F);
        displaySettings.method_10566("transformation", displayScale(0.30F));
        marker.method_5651(displaySettings);
        marker.method_32318(0).method_32332(stack);
        marker.method_5808(markerPos.field_1352, markerPos.field_1351, markerPos.field_1350, 0.0F, 0.0F);
        marker.method_5780(MARKER_TAG);
        marker.method_5780(MARKER_LAYOUT_TAG);
        marker.method_5780(markerTag(lock.lockId()));
        marker.method_5684(true);
        marker.method_5665(stack.method_7964());
        world.method_8649(marker);
    }

    private static void syncLockMarkers(class_3218 world) {
        LockState state = LockState.get(world);
        Map<UUID, MarkerTarget> targets = new HashMap<>();
        for (var entry : state.entries()) {
            class_2338 pos = class_2338.method_10092(entry.getKey());
            if (!world.method_22340(pos)) {
                continue;
            }
            LockState.LockEntry lock = entry.getValue();
            targets.putIfAbsent(lock.lockId(), new MarkerTarget(pos, lock));
        }

        List<class_1297> existingMarkers = new ArrayList<>();
        for (class_1297 entity : world.method_27909()) {
            if (entity.method_5752().contains(MARKER_TAG)) {
                existingMarkers.add(entity);
            }
        }

        Set<UUID> positioned = new HashSet<>();
        for (class_1297 marker : existingMarkers) {
            Optional<UUID> lockId = markerLockId(marker);
            MarkerTarget target = lockId.map(targets::get).orElse(null);
            if (!(marker instanceof class_8113.class_8122)
                    || !marker.method_5752().contains(MARKER_LAYOUT_TAG)
                    || lockId.isEmpty() || target == null || !positioned.add(lockId.get())) {
                marker.method_31472();
                continue;
            }

            class_243 expectedPosition = markerPosition(world, target.pos());
            if (marker.method_19538().method_1025(expectedPosition) > 0.0025) {
                marker.method_5808(expectedPosition.field_1352, expectedPosition.field_1351,
                        expectedPosition.field_1350, 0.0F, 0.0F);
            }
        }

        for (Map.Entry<UUID, MarkerTarget> entry : targets.entrySet()) {
            if (!positioned.contains(entry.getKey())) {
                MarkerTarget target = entry.getValue();
                spawnLockMarker(world, target.pos(), target.lock());
            }
        }
    }

    private static class_243 markerPosition(class_3218 world, class_2338 originalPos) {
        class_2338 pos = lowerDoorHalf(world, originalPos);
        class_2680 state = world.method_8320(pos);

        if (state.method_26204() instanceof class_2533) {
            // Anchor to the closed panel center, independently of its open state.
            double panelHeight = state.method_28498(class_2741.field_12518)
                    && "top".equals(state.method_11654(class_2741.field_12518).method_15434()) ? 0.875 : 0.125;
            return class_243.method_24955(pos).method_1031(0.0, panelHeight, 0.0);
        }

        if (state.method_26204() instanceof class_2323) {
            class_2680 fixedAnchorState = state.method_28498(class_2741.field_12537)
                    ? state.method_11657(class_2741.field_12537, false)
                    : state;
            class_243 doorFace = markerNearOutline(world, pos, fixedAnchorState, 0.76, 0.035);
            class_2350 facing = state.method_11654(class_2741.field_12481);
            boolean leftHinge = state.method_28498(class_2741.field_12520)
                    && "left".equals(state.method_11654(class_2741.field_12520).method_15434());
            class_2350 handleSide = leftHinge
                    ? facing.method_10160()
                    : facing.method_10170();
            return doorFace.method_1031(handleSide.method_10148() * 0.29, 0.0,
                    handleSide.method_10165() * 0.29);
        }

        class_2350 facing;
        if (state.method_28498(class_2741.field_12525)) {
            facing = state.method_11654(class_2741.field_12525);
        } else if (state.method_28498(class_2741.field_12481)) {
            facing = state.method_11654(class_2741.field_12481);
        } else {
            facing = class_2350.field_11035;
        }
        return class_243.method_24953(pos).method_1031(
                facing.method_10148() * 0.515,
                facing.method_10164() * 0.515,
                facing.method_10165() * 0.515
        );
    }

    private static class_243 markerNearOutline(class_3218 world, class_2338 pos, class_2680 state,
                                           double height, double outwardOffset) {
        class_238 bounds = state.method_26218(world, pos).method_1107();
        double localX = (bounds.field_1323 + bounds.field_1320) * 0.5;
        double localZ = (bounds.field_1321 + bounds.field_1324) * 0.5;
        double fromCenterX = localX - 0.5;
        double fromCenterZ = localZ - 0.5;
        double horizontalLength = Math.sqrt(fromCenterX * fromCenterX + fromCenterZ * fromCenterZ);
        if (horizontalLength > 0.001) {
            localX += fromCenterX / horizontalLength * outwardOffset;
            localZ += fromCenterZ / horizontalLength * outwardOffset;
        }
        return new class_243(pos.method_10263() + localX, pos.method_10264() + height, pos.method_10260() + localZ);
    }

    private static class_2499 displayScale(float scale) {
        class_2499 matrix = new class_2499();
        float[] values = {
                scale, 0.0F, 0.0F, 0.0F,
                0.0F, scale, 0.0F, 0.0F,
                0.0F, 0.0F, scale, 0.0F,
                0.0F, 0.0F, 0.0F, 1.0F
        };
        for (float value : values) {
            matrix.add(class_2494.method_23244(value));
        }
        return matrix;
    }

    private static class_2338 lowerDoorHalf(class_3218 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26204() instanceof class_2323
                && state.method_28498(class_2741.field_12533)
                && "upper".equals(state.method_11654(class_2741.field_12533).method_15434())) {
            class_2338 lower = pos.method_10074();
            if (world.method_8320(lower).method_27852(state.method_26204())) {
                return lower;
            }
        }
        return pos;
    }

    private static Optional<UUID> markerLockId(class_1297 marker) {
        String prefix = MOD_ID + ":";
        for (String tag : marker.method_5752()) {
            if (!tag.startsWith(prefix) || MARKER_TAG.equals(tag)) {
                continue;
            }
            try {
                return Optional.of(UUID.fromString(tag.substring(prefix.length())));
            } catch (IllegalArgumentException ignored) {
                // Ignore unrelated command tags and continue looking for the lock UUID.
            }
        }
        return Optional.empty();
    }

    private static void removeLockMarkers(class_3218 world, class_2338 pos, UUID lockId) {
        List<class_1297> matchingMarkers = new ArrayList<>();
        for (class_1297 entity : world.method_27909()) {
            if (entity.method_5752().contains(MARKER_TAG)
                    && entity.method_5752().contains(markerTag(lockId))) {
                matchingMarkers.add(entity);
            }
        }
        for (class_1297 entity : matchingMarkers) {
            entity.method_31472();
        }
    }

    private static String markerTag(UUID lockId) {
        return MOD_ID + ":" + lockId;
    }

    private record MarkerTarget(class_2338 pos, LockState.LockEntry lock) {
    }

    private static void send(class_1657 player, String translationKey) {
        player.method_7353(class_2561.method_43471(translationKey), true);
    }
}
