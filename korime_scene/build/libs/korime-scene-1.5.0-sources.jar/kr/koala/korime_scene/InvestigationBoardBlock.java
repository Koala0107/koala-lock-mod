package kr.koala.korime_scene;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1309;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2758;
import net.minecraft.class_3726;
import net.minecraft.class_4538;

public final class InvestigationBoardBlock extends class_2383 {
    public static final MapCodec<InvestigationBoardBlock> CODEC = method_54094(InvestigationBoardBlock::new);
    public static final class_2758 PART = class_2758.method_11867("part", 0, 3);

    private static final class_265 NORTH_SHAPE = class_2248.method_9541(0, 0, 15, 16, 16, 16);
    private static final class_265 SOUTH_SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 1);
    private static final class_265 WEST_SHAPE = class_2248.method_9541(15, 0, 0, 16, 16, 16);
    private static final class_265 EAST_SHAPE = class_2248.method_9541(0, 0, 0, 1, 16, 16);

    public InvestigationBoardBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043).method_11657(PART, 0));
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2350 facing = context.method_8038();
        if (!facing.method_10166().method_10179()) return null;

        class_2338 anchor = context.method_8037();
        class_2350 right = facing.method_10160();
        class_2338[] positions = new class_2338[] {
                anchor,
                anchor.method_10093(right),
                anchor.method_10084(),
                anchor.method_10084().method_10093(right)
        };

        for (int i = 0; i < positions.length; i++) {
            class_2338 partPos = positions[i];
            if (i > 0 && !context.method_8045().method_8320(partPos).method_26215()) return null;

            class_2338 supportPos = partPos.method_10093(facing.method_10153());
            if (!context.method_8045().method_8320(supportPos)
                    .method_26206(context.method_8045(), supportPos, facing)) {
                return null;
            }
        }

        return method_9564().method_11657(field_11177, facing).method_11657(PART, 0);
    }

    @Override
    public void method_9567(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack) {
        super.method_9567(world, pos, state, placer, itemStack);
        if (world.field_9236) return;

        class_2350 right = state.method_11654(field_11177).method_10160();
        world.method_8652(pos.method_10093(right), state.method_11657(PART, 1), class_2248.field_31036);
        world.method_8652(pos.method_10084(), state.method_11657(PART, 2), class_2248.field_31036);
        world.method_8652(pos.method_10084().method_10093(right), state.method_11657(PART, 3), class_2248.field_31036);
    }

    @Override
    public boolean method_9558(class_2680 state, class_4538 world, class_2338 pos) {
        class_2350 facing = state.method_11654(field_11177);
        class_2338 supportPos = pos.method_10093(facing.method_10153());
        return world.method_8320(supportPos).method_26206(world, supportPos, facing);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState,
                                                 class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (direction == state.method_11654(field_11177).method_10153() && !state.method_26184(world, pos)) {
            return class_2246.field_10124.method_9564();
        }
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2338 anchor = getAnchorPos(pos, state);
            class_2350 right = state.method_11654(field_11177).method_10160();
            class_2338[] positions = new class_2338[] {
                    anchor,
                    anchor.method_10093(right),
                    anchor.method_10084(),
                    anchor.method_10084().method_10093(right)
            };
            for (class_2338 partPos : positions) {
                if (!partPos.equals(pos) && world.method_8320(partPos).method_27852(this)) {
                    world.method_8650(partPos, false);
                }
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    private class_2338 getAnchorPos(class_2338 pos, class_2680 state) {
        class_2350 right = state.method_11654(field_11177).method_10160();
        return switch (state.method_11654(PART)) {
            case 1 -> pos.method_10093(right.method_10153());
            case 2 -> pos.method_10074();
            case 3 -> pos.method_10074().method_10093(right.method_10153());
            default -> pos;
        };
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return switch (state.method_11654(field_11177)) {
            case field_11035 -> SOUTH_SHAPE;
            case field_11039 -> WEST_SHAPE;
            case field_11034 -> EAST_SHAPE;
            default -> NORTH_SHAPE;
        };
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177, PART);
    }
}
