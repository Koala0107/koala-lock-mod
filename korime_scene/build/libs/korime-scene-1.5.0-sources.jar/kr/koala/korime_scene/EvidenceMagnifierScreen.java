package kr.koala.korime_scene;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class EvidenceMagnifierScreen extends class_437 {
    private final class_2338 pos;
    private class_342 textField;
    private int panelX, panelY, panelWidth, panelHeight;

    public EvidenceMagnifierScreen(class_2338 pos) {
        super(class_2561.method_43470("증거 돋보기"));
        this.pos = pos.method_10062();
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(330, field_22789 - 20);
        panelHeight = Math.min(150, field_22790 - 16);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;

        int innerX = panelX + 18;
        int innerWidth = panelWidth - 36;

        textField = method_37063(new class_342(field_22793,
                innerX, panelY + 55, innerWidth, 20, class_2561.method_43470("증거 문장")));
        textField.method_1880(EvidenceMagnifierBlockEntity.MAX_TEXT_LENGTH);
        textField.method_47404(class_2561.method_43470("문장 또는 JSON 텍스트를 입력해줘"));

        int gap = 8;
        int buttonWidth = (innerWidth - gap) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), b -> method_25419())
                .method_46434(innerX, panelY + 105, buttonWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("저장"), b -> save())
                .method_46434(innerX + buttonWidth + gap, panelY + 105, buttonWidth, 20).method_46431());

        textField.method_25365(true);
    }

    private void save() {
        class_2540 buf = PacketByteBufs.create();
        buf.method_10807(pos);
        buf.method_10788(textField.method_1882(), EvidenceMagnifierBlockEntity.MAX_TEXT_LENGTH);
        ClientPlayNetworking.send(SceneToolsMod.EVIDENCE_MAGNIFIER_SAVE_PACKET, buf);
        method_25419();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Keep world visible.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF080A0D);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFF0F6FA);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + 30, 0xFF287FAE);
        context.method_27534(field_22793, field_22785, panelX + panelWidth / 2, panelY + 11, 0xFFFFFFFF);
        context.method_51439(field_22793, class_2561.method_43470("증거 문장"), panelX + 18, panelY + 41, 0xFF34424B, false);
        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
