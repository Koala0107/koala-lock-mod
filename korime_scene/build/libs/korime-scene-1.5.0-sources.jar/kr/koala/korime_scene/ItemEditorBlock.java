package kr.koala.korime_scene;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public final class ItemEditorBlock extends class_2248 {
    public static final MapCodec<ItemEditorBlock> CODEC = method_54094(ItemEditorBlock::new);

    public ItemEditorBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969() {
        return field_46280;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        return class_1269.field_5812;
    }
}
