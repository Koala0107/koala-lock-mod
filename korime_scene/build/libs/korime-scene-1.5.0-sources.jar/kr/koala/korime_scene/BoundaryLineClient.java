package kr.koala.korime_scene;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.minecraft.class_1921;

public final class BoundaryLineClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(
                class_1921.method_23581(),
                BoundaryLineMod.HORIZONTAL,
                BoundaryLineMod.VERTICAL,
                BoundaryLineMod.CORNER
        );
    }
}
