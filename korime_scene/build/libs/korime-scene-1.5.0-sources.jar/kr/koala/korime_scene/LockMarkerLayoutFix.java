package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2281;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2494;
import net.minecraft.class_2499;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2750;
import net.minecraft.class_3218;
import net.minecraft.class_3708;
import net.minecraft.class_8113;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Keeps lock/keypad displays fixed to their world-facing surfaces instead of the camera. */
public final class LockMarkerLayoutFix implements ModInitializer {
    private static final String LAYOUT_TAG = KorimeSceneMod.MOD_ID + ":marker_layout_v8";
    private static final String SECONDARY_TAG = KorimeSceneMod.MOD_ID + ":secondary_marker_v7";
    private static final String SECONDARY_LOCK_PREFIX = KorimeSceneMod.MOD_ID + ":secondary_lock:";
    private static final float DISPLAY_SCALE = 0.30F;
    private static final double SURFACE_GAP = 0.125D;

    @Override
    public void onInitialize() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if ((world.method_8510() & 1L) == 0L) syncMarkerLayout(world);
        });
    }

    private static void syncMarkerLayout(class_3218 world) {
        Map<UUID, List<class_2338>> targets = collectTargets(world);
        Map<UUID, class_8113.class_8122> primary = new HashMap<>();
        Map<UUID, class_8113.class_8122> secondary = new HashMap<>();
        List<class_8113.class_8122> badSecondary = new ArrayList<>();

        for (class_1297 entity : world.method_27909()) {
            if (!(entity instanceof class_8113.class_8122 display)) continue;
            if (display.method_5752().contains(KorimeSceneMod.MARKER_TAG)) {
                markerLockId(display).ifPresent(id -> primary.putIfAbsent(id, display));
            } else if (display.method_5752().contains(SECONDARY_TAG)) {
                Optional<UUID> id = secondaryLockId(display);
                if (id.isEmpty()) {
                    badSecondary.add(display);
                } else {
                    class_8113.class_8122 duplicate = secondary.putIfAbsent(id.get(), display);
                    if (duplicate != null) badSecondary.add(display);
                }
            }
        }
        badSecondary.forEach(class_1297::method_31472);

        for (Map.Entry<UUID, class_8113.class_8122> entry : primary.entrySet()) {
            UUID lockId = entry.getKey();
            List<class_2338> positions = targets.get(lockId);
            if (positions == null || positions.isEmpty()) continue;

            PosePair poses = markerPoses(world, positions);
            applyPose(entry.getValue(), poses.primary());

            class_8113.class_8122 second = secondary.remove(lockId);
            if (poses.secondary() != null) {
                if (second == null || second.method_31481()) {
                    second = createSecondary(world, entry.getValue(), lockId);
                }
                applyPose(second, poses.secondary());
            } else if (second != null) {
                second.method_31472();
            }
        }

        for (Map.Entry<UUID, class_8113.class_8122> entry : secondary.entrySet()) {
            List<class_2338> positions = targets.get(entry.getKey());
            if (positions == null || !needsTwoSides(world, positions)) entry.getValue().method_31472();
        }
    }

    private static Map<UUID, List<class_2338>> collectTargets(class_3218 world) {
        Map<UUID, List<class_2338>> targets = new HashMap<>();
        for (Map.Entry<Long, LockState.LockEntry> entry : LockState.get(world).entries()) {
            class_2338 pos = class_2338.method_10092(entry.getKey());
            if (!world.method_22340(pos)) continue;
            targets.computeIfAbsent(entry.getValue().lockId(), ignored -> new ArrayList<>()).add(pos.method_10062());
        }
        return targets;
    }

    private static boolean needsTwoSides(class_3218 world, List<class_2338> positions) {
        if (positions == null || positions.isEmpty()) return false;
        class_2338 pos = lowerDoorHalf(world, positions.get(0));
        class_2680 state = world.method_8320(pos);
        return state.method_26204() instanceof class_2323 || state.method_26204() instanceof class_2533;
    }

    private static class_8113.class_8122 createSecondary(class_3218 world,
                                                                    class_8113.class_8122 primary,
                                                                    UUID lockId) {
        class_2487 nbt = new class_2487();
        primary.method_5647(nbt);
        nbt.method_10551("UUID");
        nbt.method_10551("Pos");
        nbt.method_10551("Motion");
        nbt.method_10551("Rotation");
        nbt.method_10551("Tags");

        class_8113.class_8122 secondary =
                new class_8113.class_8122(class_1299.field_42456, world);
        secondary.method_5651(nbt);
        secondary.method_5780(SECONDARY_TAG);
        secondary.method_5780(SECONDARY_LOCK_PREFIX + lockId);
        secondary.method_5684(true);
        world.method_8649(secondary);
        return secondary;
    }

    private static void applyPose(class_8113.class_8122 marker, MarkerPose pose) {
        class_2487 nbt = new class_2487();
        marker.method_5647(nbt);
        nbt.method_10582("billboard", "fixed");
        nbt.method_10582("item_display", "fixed");
        nbt.method_10548("width", 0.60F);
        nbt.method_10548("height", 0.60F);
        nbt.method_10566("transformation", displayScale(DISPLAY_SCALE));
        marker.method_5651(nbt);
        marker.method_5808(pose.position().field_1352, pose.position().field_1351, pose.position().field_1350,
                pose.yaw(), pose.pitch());
        marker.method_5684(true);
        marker.method_5780(LAYOUT_TAG);
    }

    private static PosePair markerPoses(class_3218 world, List<class_2338> positions) {
        class_2338 pos = lowerDoorHalf(world, positions.get(0));
        class_2680 state = world.method_8320(pos);

        if (state.method_26204() instanceof class_2533) return trapdoorPoses(world, pos, state);
        if (state.method_26204() instanceof class_2323) return doorPoses(world, pos, state);

        if (state.method_26204() instanceof class_2281) {
            class_2350 facing = state.method_11654(class_2741.field_12481);
            class_243 position = linkedBlockCenter(positions).method_1031(
                    facing.method_10148() * 0.625D, 0.0D, facing.method_10165() * 0.625D);
            return new PosePair(new MarkerPose(position, yawFor(facing), 0.0F), null);
        }

        if (state.method_26204() instanceof class_3708) {
            class_2350 facing = state.method_11654(class_2741.field_12525);
            class_243 position = class_243.method_24953(pos).method_1031(
                    facing.method_10148() * 0.625D,
                    facing.method_10164() * 0.625D,
                    facing.method_10165() * 0.625D);
            return new PosePair(new MarkerPose(position, yawFor(facing), pitchFor(facing)), null);
        }

        class_2350 facing = blockFacing(state);
        class_243 position = class_243.method_24953(pos).method_1031(
                facing.method_10148() * 0.625D,
                facing.method_10164() * 0.625D,
                facing.method_10165() * 0.625D);
        return new PosePair(new MarkerPose(position, yawFor(facing), pitchFor(facing)), null);
    }

    private static PosePair trapdoorPoses(class_3218 world, class_2338 pos, class_2680 state) {
        class_238 bounds = state.method_26218(world, pos).method_1107();
        boolean open = state.method_28498(class_2741.field_12537) && state.method_11654(class_2741.field_12537);

        if (!open) {
            class_2350 facing = state.method_28498(class_2741.field_12481)
                    ? state.method_11654(class_2741.field_12481) : class_2350.field_11035;
            double x = pos.method_10263() + (bounds.field_1323 + bounds.field_1320) * 0.5D;
            double z = pos.method_10260() + (bounds.field_1321 + bounds.field_1324) * 0.5D;
            MarkerPose top = new MarkerPose(
                    new class_243(x, pos.method_10264() + bounds.field_1325 + SURFACE_GAP, z),
                    yawFor(facing), -90.0F);
            MarkerPose bottom = new MarkerPose(
                    new class_243(x, pos.method_10264() + bounds.field_1322 - SURFACE_GAP, z),
                    yawFor(facing.method_10153()), 90.0F);
            return new PosePair(top, bottom);
        }

        class_2350 normal = horizontalNormalFromBounds(bounds);
        double x = pos.method_10263() + (bounds.field_1323 + bounds.field_1320) * 0.5D;
        double y = pos.method_10264() + (bounds.field_1322 + bounds.field_1325) * 0.5D;
        double z = pos.method_10260() + (bounds.field_1321 + bounds.field_1324) * 0.5D;
        class_243 center = new class_243(x, y, z);
        class_243 offset = directionVector(normal).method_1021(halfThickness(bounds, normal) + SURFACE_GAP);
        return new PosePair(
                new MarkerPose(center.method_1019(offset), yawFor(normal), 0.0F),
                new MarkerPose(center.method_1020(offset), yawFor(normal.method_10153()), 0.0F));
    }

    private static PosePair doorPoses(class_3218 world, class_2338 pos, class_2680 state) {
        class_2680 closedState = state.method_28498(class_2741.field_12537) ? state.method_11657(class_2741.field_12537, false) : state;
        class_238 closedBounds = closedState.method_26218(world, pos).method_1107();
        class_238 currentBounds = state.method_26218(world, pos).method_1107();
        class_2350 facing = state.method_11654(class_2741.field_12481);
        boolean leftHinge = state.method_28498(class_2741.field_12520)
                && state.method_11654(class_2741.field_12520) == class_2750.field_12588;
        class_2350 hingeSide = leftHinge ? facing.method_10170() : facing.method_10160();

        class_243 closedCenter = new class_243(
                pos.method_10263() + (closedBounds.field_1323 + closedBounds.field_1320) * 0.5D,
                pos.method_10264() + 0.95D,
                pos.method_10260() + (closedBounds.field_1321 + closedBounds.field_1324) * 0.5D);
        class_243 pivot = closedCenter.method_1020(directionVector(hingeSide).method_1021(0.5D));
        class_243 currentCenter = new class_243(
                pos.method_10263() + (currentBounds.field_1323 + currentBounds.field_1320) * 0.5D,
                pos.method_10264() + 0.95D,
                pos.method_10260() + (currentBounds.field_1321 + currentBounds.field_1324) * 0.5D);
        class_243 delta = currentCenter.method_1020(pivot);
        class_243 radial = delta.method_1027() < 1.0E-4D ? directionVector(hingeSide) : delta.method_1029();
        class_243 panelCenter = pivot.method_1019(radial.method_1021(0.8D));

        class_2350 normal = horizontalNormalFromBounds(currentBounds);
        class_243 offset = directionVector(normal).method_1021(halfThickness(currentBounds, normal) + SURFACE_GAP);
        return new PosePair(
                new MarkerPose(panelCenter.method_1019(offset), yawFor(normal), 0.0F),
                new MarkerPose(panelCenter.method_1020(offset), yawFor(normal.method_10153()), 0.0F));
    }

    private static class_2350 horizontalNormalFromBounds(class_238 bounds) {
        double x = (bounds.field_1323 + bounds.field_1320) * 0.5D - 0.5D;
        double z = (bounds.field_1321 + bounds.field_1324) * 0.5D - 0.5D;
        if (Math.abs(x) >= Math.abs(z) && Math.abs(x) > 0.001D) return x > 0 ? class_2350.field_11034 : class_2350.field_11039;
        if (Math.abs(z) > 0.001D) return z > 0 ? class_2350.field_11035 : class_2350.field_11043;
        return class_2350.field_11035;
    }

    private static double halfThickness(class_238 bounds, class_2350 normal) {
        return switch (normal.method_10166()) {
            case field_11048 -> (bounds.field_1320 - bounds.field_1323) * 0.5D;
            case field_11052 -> (bounds.field_1325 - bounds.field_1322) * 0.5D;
            case field_11051 -> (bounds.field_1324 - bounds.field_1321) * 0.5D;
        };
    }

    private static class_243 directionVector(class_2350 direction) {
        return new class_243(direction.method_10148(), direction.method_10164(), direction.method_10165());
    }

    private static class_243 linkedBlockCenter(List<class_2338> positions) {
        double x = 0, y = 0, z = 0;
        for (class_2338 pos : positions) {
            class_243 center = class_243.method_24953(pos);
            x += center.field_1352;
            y += center.field_1351;
            z += center.field_1350;
        }
        double count = Math.max(1, positions.size());
        return new class_243(x / count, y / count, z / count);
    }

    private static class_2350 blockFacing(class_2680 state) {
        if (state.method_28498(class_2741.field_12525)) return state.method_11654(class_2741.field_12525);
        if (state.method_28498(class_2741.field_12481)) return state.method_11654(class_2741.field_12481);
        return class_2350.field_11035;
    }

    private static float yawFor(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> 180.0F;
            case field_11034 -> -90.0F;
            case field_11039 -> 90.0F;
            default -> 0.0F;
        };
    }

    private static float pitchFor(class_2350 direction) {
        return switch (direction) {
            case field_11036 -> -90.0F;
            case field_11033 -> 90.0F;
            default -> 0.0F;
        };
    }

    private static class_2499 displayScale(float scale) {
        class_2499 matrix = new class_2499();
        float[] values = {
                scale, 0, 0, 0,
                0, scale, 0, 0,
                0, 0, scale, 0,
                0, 0, 0, 1
        };
        for (float value : values) matrix.add(class_2494.method_23244(value));
        return matrix;
    }

    private static class_2338 lowerDoorHalf(class_3218 world, class_2338 pos) {
        class_2680 state = world.method_8320(pos);
        if (state.method_26204() instanceof class_2323
                && state.method_28498(class_2741.field_12533)
                && "upper".equals(state.method_11654(class_2741.field_12533).method_15434())) {
            class_2338 lower = pos.method_10074();
            if (world.method_8320(lower).method_27852(state.method_26204())) return lower;
        }
        return pos;
    }

    private static Optional<UUID> markerLockId(class_1297 marker) {
        String prefix = KorimeSceneMod.MOD_ID + ":";
        for (String tag : marker.method_5752()) {
            if (!tag.startsWith(prefix) || KorimeSceneMod.MARKER_TAG.equals(tag)
                    || tag.startsWith(KorimeSceneMod.MOD_ID + ":marker_layout_")) continue;
            try {
                return Optional.of(UUID.fromString(tag.substring(prefix.length())));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return Optional.empty();
    }

    private static Optional<UUID> secondaryLockId(class_1297 marker) {
        for (String tag : marker.method_5752()) {
            if (!tag.startsWith(SECONDARY_LOCK_PREFIX)) continue;
            try {
                return Optional.of(UUID.fromString(tag.substring(SECONDARY_LOCK_PREFIX.length())));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return Optional.empty();
    }

    private record MarkerPose(class_243 position, float yaw, float pitch) {
    }

    private record PosePair(MarkerPose primary, MarkerPose secondary) {
    }
}
