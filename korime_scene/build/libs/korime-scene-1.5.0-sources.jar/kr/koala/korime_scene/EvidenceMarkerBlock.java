package kr.koala.korime_scene;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3726;

public final class EvidenceMarkerBlock extends class_2383 {
    public static final MapCodec<EvidenceMarkerBlock> CODEC = method_54094(EvidenceMarkerBlock::new);
    private static final class_265 SHAPE = class_2248.method_9541(5.0, 0.0, 5.0, 11.0, 5.0, 11.0);

    public EvidenceMarkerBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override
    protected MapCodec<? extends class_2383> method_53969() {
        return field_46280;
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(field_11177, context.method_8042());
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public boolean method_9516(class_2680 state, class_1922 world, class_2338 pos, class_10 type) {
        return false;
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(field_11177)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(field_11177);
    }
}
