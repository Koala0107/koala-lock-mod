package kr.koala.korime_scene;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2540;

/** Per-item smartphone evidence data stored directly in the ItemStack NBT. */
public final class SmartphoneData {
    public static final int MAX_RECORDS = 32;
    public static final int MAX_NAME_LENGTH = 32;
    public static final int MAX_DETAIL_LENGTH = 160;
    public static final int MAX_TIME_LENGTH = 16;
    public static final int MAX_TITLE_LENGTH = 48;
    public static final int MAX_SUBTITLE_LENGTH = 120;

    private static final String ROOT_KEY = "CrouchLockSmartphone";
    private static final String CALLS_KEY = "Calls";
    private static final String MESSAGES_KEY = "Messages";
    private static final String FINALIZED_KEY = "Finalized";
    private static final String TITLE_KEY = "EvidenceTitle";
    private static final String SUBTITLE_KEY = "EvidenceSubtitle";
    private static final String NAME_KEY = "Name";
    private static final String DETAIL_KEY = "Detail";
    private static final String TIME_KEY = "Time";
    private static final String OUTGOING_KEY = "Outgoing";

    private final List<PhoneRecord> calls;
    private final List<PhoneRecord> messages;
    private final boolean finalized;
    private final String title;
    private final String subtitle;

    public SmartphoneData(List<PhoneRecord> calls, List<PhoneRecord> messages) {
        this(calls, messages, true, "", "");
    }

    public SmartphoneData(List<PhoneRecord> calls, List<PhoneRecord> messages, boolean finalized) {
        this(calls, messages, finalized, "", "");
    }

    public SmartphoneData(List<PhoneRecord> calls, List<PhoneRecord> messages, boolean finalized,
                          String title, String subtitle) {
        this.calls = copyAndLimit(calls);
        this.messages = copyAndLimit(messages);
        this.finalized = finalized;
        this.title = sanitize(title, MAX_TITLE_LENGTH);
        this.subtitle = sanitize(subtitle, MAX_SUBTITLE_LENGTH);
    }

    public static SmartphoneData empty() {
        return new SmartphoneData(List.of(), List.of(), false, "", "");
    }

    public static SmartphoneData fromStack(class_1799 stack) {
        class_2487 stackNbt = stack.method_7969();
        if (stackNbt == null || !stackNbt.method_10573(ROOT_KEY, class_2520.field_33260)) return empty();
        class_2487 phone = stackNbt.method_10562(ROOT_KEY);
        return new SmartphoneData(
                readNbtList(phone.method_10554(CALLS_KEY, class_2520.field_33260)),
                readNbtList(phone.method_10554(MESSAGES_KEY, class_2520.field_33260)),
                phone.method_10577(FINALIZED_KEY), phone.method_10558(TITLE_KEY), phone.method_10558(SUBTITLE_KEY));
    }

    public List<PhoneRecord> calls() { return List.copyOf(calls); }
    public List<PhoneRecord> messages() { return List.copyOf(messages); }
    public boolean finalized() { return finalized; }
    public String title() { return title; }
    public String subtitle() { return subtitle; }

    public void writeTo(class_1799 stack) {
        class_2487 phone = new class_2487();
        phone.method_10566(CALLS_KEY, writeNbtList(calls));
        phone.method_10566(MESSAGES_KEY, writeNbtList(messages));
        phone.method_10556(FINALIZED_KEY, finalized);
        phone.method_10582(TITLE_KEY, title);
        phone.method_10582(SUBTITLE_KEY, subtitle);
        stack.method_7948().method_10566(ROOT_KEY, phone);
    }

    public void writePacket(class_2540 buf) {
        buf.method_52964(finalized);
        buf.method_10788(title, MAX_TITLE_LENGTH);
        buf.method_10788(subtitle, MAX_SUBTITLE_LENGTH);
        writePacketList(buf, calls);
        writePacketList(buf, messages);
    }

    public static SmartphoneData readPacket(class_2540 buf) {
        boolean finalized = buf.readBoolean();
        String title = buf.method_10800(MAX_TITLE_LENGTH);
        String subtitle = buf.method_10800(MAX_SUBTITLE_LENGTH);
        return new SmartphoneData(readPacketList(buf), readPacketList(buf), finalized, title, subtitle);
    }

    private static List<PhoneRecord> readNbtList(class_2499 list) {
        List<PhoneRecord> records = new ArrayList<>();
        for (int i = 0; i < Math.min(list.size(), MAX_RECORDS); i++) {
            class_2487 record = list.method_10602(i);
            records.add(new PhoneRecord(record.method_10558(NAME_KEY), record.method_10558(DETAIL_KEY),
                    record.method_10558(TIME_KEY), record.method_10577(OUTGOING_KEY)));
        }
        return records;
    }

    private static class_2499 writeNbtList(List<PhoneRecord> records) {
        class_2499 list = new class_2499();
        for (int i = 0; i < Math.min(records.size(), MAX_RECORDS); i++) {
            PhoneRecord record = records.get(i);
            class_2487 tag = new class_2487();
            tag.method_10582(NAME_KEY, record.name());
            tag.method_10582(DETAIL_KEY, record.detail());
            tag.method_10582(TIME_KEY, record.time());
            tag.method_10556(OUTGOING_KEY, record.outgoing());
            list.add(tag);
        }
        return list;
    }

    private static void writePacketList(class_2540 buf, List<PhoneRecord> records) {
        int count = Math.min(records.size(), MAX_RECORDS);
        buf.method_10804(count);
        for (int i = 0; i < count; i++) {
            PhoneRecord record = records.get(i);
            buf.method_10788(record.name(), MAX_NAME_LENGTH);
            buf.method_10788(record.detail(), MAX_DETAIL_LENGTH);
            buf.method_10788(record.time(), MAX_TIME_LENGTH);
            buf.method_52964(record.outgoing());
        }
    }

    private static List<PhoneRecord> readPacketList(class_2540 buf) {
        int count = buf.method_10816();
        if (count < 0 || count > MAX_RECORDS) throw new IllegalArgumentException("Invalid smartphone record count: " + count);
        List<PhoneRecord> records = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            records.add(new PhoneRecord(buf.method_10800(MAX_NAME_LENGTH), buf.method_10800(MAX_DETAIL_LENGTH),
                    buf.method_10800(MAX_TIME_LENGTH), buf.readBoolean()));
        }
        return records;
    }

    private static List<PhoneRecord> copyAndLimit(List<PhoneRecord> source) {
        List<PhoneRecord> result = new ArrayList<>();
        for (int i = 0; i < Math.min(source.size(), MAX_RECORDS); i++) {
            PhoneRecord record = source.get(i);
            result.add(new PhoneRecord(record.name(), record.detail(), record.time(), record.outgoing()));
        }
        return result;
    }

    private static String sanitize(String value, int maxLength) {
        if (value == null) return "";
        String cleaned = value.replace('\n', ' ').replace('\r', ' ');
        return cleaned.length() <= maxLength ? cleaned : cleaned.substring(0, maxLength);
    }

    public record PhoneRecord(String name, String detail, String time, boolean outgoing) {
        public PhoneRecord(String name, String detail, String time) { this(name, detail, time, false); }
        public PhoneRecord {
            name = sanitize(name, MAX_NAME_LENGTH);
            detail = sanitize(detail, MAX_DETAIL_LENGTH);
            time = sanitize(time, MAX_TIME_LENGTH);
        }
    }
}
