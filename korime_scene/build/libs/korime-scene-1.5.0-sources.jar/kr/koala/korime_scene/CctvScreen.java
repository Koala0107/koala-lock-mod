package kr.koala.korime_scene;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public final class CctvScreen extends class_437 {
    private final List<String> records;
    private final List<class_5481> wrapped = new ArrayList<>();
    private int scroll;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    public CctvScreen(List<String> records) {
        super(class_2561.method_43471("screen.korime_scene.cctv.title"));
        this.records = List.copyOf(records);
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(330, field_22789 - 24);
        panelHeight = Math.min(220, field_22790 - 24);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;
        rebuildWrapped();
    }

    private void rebuildWrapped() {
        wrapped.clear();
        int lineWidth = Math.max(80, panelWidth - 40);
        if (records.isEmpty()) {
            wrapped.add(class_2561.method_43471("screen.korime_scene.cctv.empty").method_30937());
        } else {
            for (int i = 0; i < records.size(); i++) {
                wrapped.addAll(field_22793.method_1728(class_2561.method_43470((i + 1) + ". " + records.get(i)), lineWidth));
                wrapped.add(class_2561.method_43470(" ").method_30937());
            }
        }
        scroll = Math.min(scroll, maxScroll());
    }

    private int visibleLines() {
        return Math.max(1, (panelHeight - 50) / 11);
    }

    private int maxScroll() {
        return Math.max(0, wrapped.size() - visibleLines());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (verticalAmount > 0) scroll = Math.max(0, scroll - 2);
        if (verticalAmount < 0) scroll = Math.min(maxScroll(), scroll + 2);
        return true;
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Keep the world visible behind the CCTV log window.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF080A0D);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFE7E8EA);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + 30, 0xFF22272D);
        context.method_25294(panelX + 12, panelY + 38, panelX + panelWidth - 12, panelY + panelHeight - 12, 0xFFF7F7F7);

        context.method_27534(field_22793, field_22785, panelX + panelWidth / 2, panelY + 11, 0xFFFFFFFF);

        int y = panelY + 45;
        int end = Math.min(wrapped.size(), scroll + visibleLines());
        for (int i = scroll; i < end; i++) {
            context.method_51430(field_22793, wrapped.get(i), panelX + 20, y, 0xFF24282C, false);
            y += 11;
        }

        if (maxScroll() > 0) {
            int trackTop = panelY + 44;
            int trackBottom = panelY + panelHeight - 18;
            int thumbHeight = Math.max(16, (trackBottom - trackTop) * visibleLines() / wrapped.size());
            int thumbY = trackTop + (trackBottom - trackTop - thumbHeight) * scroll / maxScroll();
            context.method_25294(panelX + panelWidth - 18, trackTop, panelX + panelWidth - 15, trackBottom, 0xFFD0D2D4);
            context.method_25294(panelX + panelWidth - 18, thumbY, panelX + panelWidth - 15, thumbY + thumbHeight, 0xFF5C6570);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
