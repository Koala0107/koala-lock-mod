package kr.koala.korime_scene;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class EvidenceTextUtil {
    private EvidenceTextUtil() { }

    public static class_2561 parse(String raw) {
        if (raw == null || raw.isEmpty()) return class_2561.method_43473();
        String trimmed = raw.trim();

        try {
            JsonElement root = JsonParser.parseString(trimmed);
            return parseElement(root, 0);
        } catch (RuntimeException ignored) {
            return class_2561.method_43470(raw);
        }
    }

    private static class_5250 parseElement(JsonElement element, int depth) {
        if (depth > 16 || element == null || element.isJsonNull()) return class_2561.method_43473();

        if (element.isJsonPrimitive()) {
            if (element.getAsJsonPrimitive().isString()) {
                String value = element.getAsString();
                String nested = value.trim();
                if (depth < 3 && ((nested.startsWith("{") && nested.endsWith("}")) ||
                        (nested.startsWith("[") && nested.endsWith("]")))) {
                    try {
                        return parseElement(JsonParser.parseString(nested), depth + 1);
                    } catch (RuntimeException ignored) { }
                }
                return class_2561.method_43470(value);
            }
            return class_2561.method_43470(element.getAsString());
        }

        if (element.isJsonArray()) {
            class_5250 result = class_2561.method_43473();
            JsonArray array = element.getAsJsonArray();
            for (JsonElement child : array) result.method_10852(parseElement(child, depth + 1));
            return result;
        }

        JsonObject obj = element.getAsJsonObject();
        class_5250 result = class_2561.method_43473();
        if (obj.has("text") && !obj.get("text").isJsonNull()) {
            result = class_2561.method_43470(obj.get("text").getAsString());
        }

        if (obj.has("color") && obj.get("color").isJsonPrimitive()) {
            class_124 color = class_124.method_533(obj.get("color").getAsString().toLowerCase());
            if (color != null) result.method_27692(color);
        }
        if (bool(obj, "bold")) result.method_27692(class_124.field_1067);
        if (bool(obj, "italic")) result.method_27692(class_124.field_1056);
        if (bool(obj, "underlined")) result.method_27692(class_124.field_1073);
        if (bool(obj, "strikethrough")) result.method_27692(class_124.field_1055);
        if (bool(obj, "obfuscated")) result.method_27692(class_124.field_1051);

        if (obj.has("extra") && obj.get("extra").isJsonArray()) {
            for (JsonElement child : obj.getAsJsonArray("extra")) {
                result.method_10852(parseElement(child, depth + 1));
            }
        }
        return result;
    }

    private static boolean bool(JsonObject obj, String key) {
        try {
            return obj.has(key) && obj.get(key).isJsonPrimitive() && obj.get(key).getAsBoolean();
        } catch (RuntimeException ignored) {
            return false;
        }
    }
}
