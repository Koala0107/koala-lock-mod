package kr.koala.korime_scene;

import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;

public final class EvidenceMagnifierBlockEntity extends class_2586 {
    public static final int MAX_TEXT_LENGTH = 2048;

    private String evidenceText = "";
    private boolean saved;

    public EvidenceMagnifierBlockEntity(class_2338 pos, class_2680 state) {
        super(SceneToolsMod.EVIDENCE_MAGNIFIER_BLOCK_ENTITY, pos, state);
    }

    public String getEvidenceText() { return evidenceText; }
    public boolean isSaved() { return saved; }

    public void saveEvidence(String text) {
        if (saved) return;
        String clean = text == null ? "" : text.trim();
        if (clean.length() > MAX_TEXT_LENGTH) clean = clean.substring(0, MAX_TEXT_LENGTH);
        evidenceText = clean;
        saved = true;
        sync();
    }

    private void sync() {
        method_5431();
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14178().method_14128(field_11867);
        }
    }

    @Override
    protected void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        nbt.method_10582("EvidenceText", evidenceText);
        nbt.method_10556("Saved", saved);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        evidenceText = nbt.method_10558("EvidenceText");
        if (evidenceText.length() > MAX_TEXT_LENGTH) evidenceText = evidenceText.substring(0, MAX_TEXT_LENGTH);
        saved = nbt.method_10577("Saved");
    }

    @Override public class_2487 method_16887() { return method_38244(); }
    @Override public @Nullable class_2596<class_2602> method_38235() { return class_2622.method_38585(this); }
}
