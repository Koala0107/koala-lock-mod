package kr.koala.korime_scene;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4185;
import net.minecraft.class_465;

/** A real button UI: no fake item stacks or chest slots are used. */
public final class KeypadScreen extends class_465<KeypadScreenHandler> {
    private static final int PANEL_WIDTH = 180;
    private static final int PANEL_HEIGHT = 210;
    private static final int BUTTON_SIZE = 32;
    private static final int BUTTON_GAP = 4;

    private String input = "";
    private int seenErrorCounter;
    private int errorTicks;

    public KeypadScreen(KeypadScreenHandler handler, net.minecraft.class_1661 inventory,
                        class_2561 title) {
        super(handler, inventory, title);
        field_2792 = PANEL_WIDTH;
        field_2779 = PANEL_HEIGHT;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int gridWidth = BUTTON_SIZE * 3 + BUTTON_GAP * 2;
        int left = (field_22789 - gridWidth) / 2;
        int top = (field_22790 - PANEL_HEIGHT) / 2 + 62;

        for (int digit = 1; digit <= 9; digit++) {
            int value = digit;
            int column = (digit - 1) % 3;
            int row = (digit - 1) / 3;
            method_37063(class_4185.method_46430(class_2561.method_43470(Integer.toString(digit)), button -> press(value))
                    .method_46434(left + column * (BUTTON_SIZE + BUTTON_GAP),
                            top + row * (BUTTON_SIZE + BUTTON_GAP), BUTTON_SIZE, BUTTON_SIZE)
                    .method_46431());
        }

        method_37063(class_4185.method_46430(class_2561.method_43470("0"), button -> press(0))
                .method_46434(left + BUTTON_SIZE + BUTTON_GAP,
                        top + 3 * (BUTTON_SIZE + BUTTON_GAP), BUTTON_SIZE, BUTTON_SIZE)
                .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.clear"), button -> {
                    input = "";
                    playKeySound(0.65F);
                    click(KeypadScreenHandler.CLEAR_BUTTON);
                })
                .method_46434(left, top + 3 * (BUTTON_SIZE + BUTTON_GAP), BUTTON_SIZE, BUTTON_SIZE)
                .method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43471("screen.korime_scene.confirm"), button -> {
                    if (input.length() >= KeypadScreenHandler.MIN_DIGITS
                            && input.length() <= KeypadScreenHandler.MAX_DIGITS) {
                        playKeySound(1.55F);
                        click(KeypadScreenHandler.CONFIRM_BUTTON);
                        input = "";
                    }
                })
                .method_46434(left + 2 * (BUTTON_SIZE + BUTTON_GAP),
                        top + 3 * (BUTTON_SIZE + BUTTON_GAP), BUTTON_SIZE, BUTTON_SIZE)
                .method_46431());
    }

    @Override
    protected void method_37432() {
        super.method_37432();
        int currentErrorCounter = field_2797.getErrorCounter();
        if (currentErrorCounter != seenErrorCounter) {
            seenErrorCounter = currentErrorCounter;
            errorTicks = 40;
        } else if (errorTicks > 0) {
            errorTicks--;
        }
    }

    private void press(int digit) {
        if (input.length() < KeypadScreenHandler.MAX_DIGITS) {
            input += digit;
            playKeySound(0.8F + digit * 0.06F);
            click(digit);
        }
    }

    private void playKeySound(float pitch) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 != null) {
            client.field_1724.method_5783(class_3417.field_15114.comp_349(), 0.55F, pitch);
        }
    }

    private void click(int buttonId) {
        class_310 client = class_310.method_1551();
        if (client.field_1761 != null) {
            client.field_1761.method_2900(field_2797.field_7763, buttonId);
        }
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int left = (field_22789 - PANEL_WIDTH) / 2;
        int top = (field_22790 - PANEL_HEIGHT) / 2;
        int center = field_22789 / 2;
        context.method_25294(left, top, left + PANEL_WIDTH, top + PANEL_HEIGHT, 0xF0181822);
        context.method_25294(left + 4, top + 4, left + PANEL_WIDTH - 4, top + PANEL_HEIGHT - 4, 0xFF303544);
        context.method_27534(field_22793, field_22785, center, top + 11, 0xFFFFFF);
        context.method_25294(left + 25, top + 25, left + PANEL_WIDTH - 25, top + 43,
                errorTicks > 0 ? 0xFF9B2525 : 0xFF171B24);
        context.method_27534(field_22793,
                class_2561.method_43470("*".repeat(input.length())
                                + "_".repeat(KeypadScreenHandler.MAX_DIGITS - input.length()))
                        .method_27692(class_124.field_1075),
                center, top + 30, errorTicks > 0 ? 0xFFFFD0D0 : 0xFFFFFF);
        context.method_27534(field_22793,
                class_2561.method_43471("screen.korime_scene.length_hint").method_27692(class_124.field_1080),
                center, top + 48, 0xFFFFFF);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // The keypad has no inventory slots, so suppress HandledScreen's default
        // title and player-inventory ("보관함") labels. The centered title is
        // already drawn as part of our custom panel above.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);
        method_2380(context, mouseX, mouseY);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
