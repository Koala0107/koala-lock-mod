package kr.koala.korime_scene;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.ArmorRenderer;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5602;
import net.minecraft.class_572;
import net.minecraft.class_630;

public final class DetectiveItemsClient implements ClientModInitializer {
    private static final class_2960 LAYER_1 = new class_2960(KorimeSceneMod.MOD_ID, "textures/models/armor/detective_layer_1.png");

    private class_572<class_1309> outerArmorModel;

    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(DetectiveItemsMod.MAGNIFYING_GLASS_BLOCK, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(DetectiveItemsMod.INVESTIGATION_BOARD_BLOCK, class_1921.method_23581());

        ArmorRenderer.register((matrices, vertexConsumers, stack, entity, slot, light, contextModel) -> {
            class_572<class_1309> model = getOuterArmorModel();
            if (model == null) return;

            contextModel.method_2818(model);
            model.method_2805(false);
            switch (slot) {
                case field_6169 -> {
                    model.field_3398.field_3665 = true;
                    model.field_3394.field_3665 = true;
                }
                case field_6174 -> {
                    model.field_3391.field_3665 = true;
                    model.field_3401.field_3665 = true;
                    model.field_27433.field_3665 = true;
                }
                default -> { }
            }

            ArmorRenderer.renderPart(matrices, vertexConsumers, light, stack, model, LAYER_1);
        }, DetectiveItemsMod.DETECTIVE_HELMET, DetectiveItemsMod.DETECTIVE_CHESTPLATE);
    }

    private class_572<class_1309> getOuterArmorModel() {
        if (outerArmorModel != null) return outerArmorModel;
        class_310 client = class_310.method_1551();
        if (client == null || client.method_31974() == null) return null;
        class_630 root = client.method_31974().method_32072(class_5602.field_27580);
        outerArmorModel = new class_572<>(root);
        return outerArmorModel;
    }
}
