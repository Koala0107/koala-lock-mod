package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2281;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_2745;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import java.util.Optional;

/** Restores the key-unlock sound behavior without changing lock display placement. */
public final class KeyUnlockSound implements ModInitializer {
    @Override
    public void onInitialize() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.field_9236 || !(world instanceof class_3218 serverWorld) || player.method_5715()) {
                return class_1269.field_5811;
            }

            Optional<LockState.LockEntry> lock = findLock(serverWorld, hit.method_17777());
            if (lock.isEmpty() || !KorimeSceneMod.KEY_LOCK.equals(lock.get().type())) {
                return class_1269.field_5811;
            }

            class_1799 held = player.method_5998(hand);
            boolean correct = LockKeyItem.getKeyId(held)
                    .map(id -> id.toString().equals(lock.get().credential()))
                    .orElse(false);
            if (!correct) {
                return class_1269.field_5811;
            }

            serverWorld.method_8396(null, hit.method_17777(), class_3417.field_14833,
                    class_3419.field_15248, 0.55F, 1.75F);
            return class_1269.field_5811;
        });
    }

    private static Optional<LockState.LockEntry> findLock(class_3218 world, class_2338 pos) {
        LockState lockState = LockState.get(world);
        Optional<LockState.LockEntry> direct = lockState.get(pos);
        if (direct.isPresent()) return direct;

        class_2680 state = world.method_8320(pos);
        if (!(state.method_26204() instanceof class_2281)
                || !state.method_28498(class_2741.field_12506)
                || state.method_11654(class_2741.field_12506) == class_2745.field_12569) {
            return Optional.empty();
        }

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 neighborPos = pos.method_10093(direction);
            class_2680 neighbor = world.method_8320(neighborPos);
            if (!neighbor.method_27852(state.method_26204())
                    || !neighbor.method_28498(class_2741.field_12506)
                    || neighbor.method_11654(class_2741.field_12506) == class_2745.field_12569) continue;
            Optional<LockState.LockEntry> linked = lockState.get(neighborPos);
            if (linked.isPresent()) return linked;
        }
        return Optional.empty();
    }
}
