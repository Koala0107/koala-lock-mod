package kr.koala.korime_scene;

import net.minecraft.class_1750;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;

public final class BoundaryEdgeBlock extends BoundaryLineBlock {
    public static final class_2746 FLIPPED = class_2746.method_11825("flipped");

    private final boolean horizontal;

    public BoundaryEdgeBlock(class_2251 settings, boolean horizontal) {
        super(settings);
        this.horizontal = horizontal;
        method_9590(method_9595().method_11664().method_11657(FLIPPED, false));
    }

    @Override
    public class_2680 method_9605(class_1750 context) {
        class_2338 pos = context.method_8037();
        double localCoordinate = horizontal
                ? context.method_17698().method_10215() - pos.method_10260()
                : context.method_17698().method_10216() - pos.method_10263();
        return method_9564().method_11657(FLIPPED, localCoordinate >= 0.5D);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FLIPPED);
    }
}
