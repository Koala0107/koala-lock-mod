package kr.koala.korime_scene;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2383;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

public final class EvidenceMagnifierBlock extends class_2383 implements class_2343 {
    public static final MapCodec<EvidenceMagnifierBlock> CODEC = method_54094(EvidenceMagnifierBlock::new);

    // The rendered magnifier is a vertical card centered in the block. Keep the
    // interaction outline on that card instead of the old floor-level shape.
    private static final class_265 NORTH_SOUTH_SHAPE = class_2248.method_9541(4, 4, 7.25, 12, 12, 8.75);
    private static final class_265 EAST_WEST_SHAPE = class_2248.method_9541(7.25, 4, 4, 8.75, 12, 12);

    public EvidenceMagnifierBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664().method_11657(field_11177, class_2350.field_11043));
    }

    @Override protected MapCodec<? extends class_2383> method_53969() { return field_46280; }

    @Override
    public @Nullable class_2680 method_9605(class_1750 context) {
        return method_9564().method_11657(field_11177, context.method_8042().method_10153());
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        class_2350 facing = state.method_11654(field_11177);
        return facing == class_2350.field_11034 || facing == class_2350.field_11039 ? EAST_WEST_SHAPE : NORTH_SOUTH_SHAPE;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, net.minecraft.class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236 && world.method_8321(pos) instanceof EvidenceMagnifierBlockEntity evidence && evidence.isSaved()) {
            world.method_8396(null, pos, class_3417.field_14793.comp_349(), class_3419.field_15245, 0.75F, 0.85F);
            if (world instanceof class_3218 serverWorld) serverWorld.method_39279(pos, this, 2);
            player.method_7353(EvidenceTextUtil.parse(evidence.getEvidenceText()), false);
        }
        return class_1269.field_5812;
    }

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_8321(pos) instanceof EvidenceMagnifierBlockEntity evidence && evidence.isSaved()) {
            world.method_8396(null, pos, class_3417.field_14725.comp_349(), class_3419.field_15245, 0.85F, 1.25F);
        }
    }

    @Override public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) { return new EvidenceMagnifierBlockEntity(pos, state); }
    @Override public class_2680 method_9598(class_2680 state, class_2470 rotation) { return state.method_11657(field_11177, rotation.method_10503(state.method_11654(field_11177))); }
    @Override public class_2680 method_9569(class_2680 state, class_2415 mirror) { return state.method_26186(mirror.method_10345(state.method_11654(field_11177))); }
    @Override protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) { builder.method_11667(field_11177); }
}
