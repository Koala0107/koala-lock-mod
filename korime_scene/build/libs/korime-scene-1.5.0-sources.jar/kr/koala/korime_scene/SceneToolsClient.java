package kr.koala.korime_scene;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1921;
import net.minecraft.class_310;

public final class SceneToolsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(SceneToolsMod.CCTV, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(SceneToolsMod.EVIDENCE_MAGNIFIER, class_1921.method_23581());

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.field_9236) return class_1269.field_5811;

            class_310 client = class_310.method_1551();
            if (client.field_1755 != null) return class_1269.field_5811;

            if (world.method_8321(hit.method_17777()) instanceof EvidenceMagnifierBlockEntity evidence) {
                if (!evidence.isSaved()) {
                    client.method_1507(new EvidenceMagnifierScreen(hit.method_17777()));
                    return class_1269.field_5812;
                }
                return class_1269.field_5811;
            }

            if (world.method_8321(hit.method_17777()) instanceof CctvBlockEntity cctv) {
                if (cctv.isFinalized()) {
                    client.method_1507(new CctvScreen(cctv.getRecords()));
                } else {
                    client.method_1507(new CctvEditorScreen(hit.method_17777(), cctv.getRecords()));
                }
                return class_1269.field_5812;
            }

            if (world.method_8320(hit.method_17777()).method_27852(SceneToolsMod.ITEM_EDITOR)) {
                client.method_1507(new ItemEditorScreen(hit.method_17777(), player.method_6047().method_7972()));
                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });
    }
}
