package kr.koala.korime_scene;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1297;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_8113;
import java.util.ArrayList;
import java.util.List;

/** Manual escape hatch for old orphaned display entities left by earlier builds. */
public final class LockMarkerCleanupMod implements ModInitializer {
    private static final String SECONDARY_MARKER_TAG = KorimeSceneMod.MOD_ID + ":secondary_marker_v7";
    private static final String SECONDARY_LOCK_PREFIX = KorimeSceneMod.MOD_ID + ":secondary_lock:";
    private static final String LAYOUT_PREFIX = KorimeSceneMod.MOD_ID + ":marker_layout_";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                dispatcher.register(class_2170.method_9247("korime_scene")
                        .then(class_2170.method_9247("cleanup")
                                .executes(context -> cleanup(context.getSource().method_9225(), context.getSource())))));
    }

    private static int cleanup(class_3218 world, net.minecraft.class_2168 source) {
        List<class_1297> remove = new ArrayList<>();
        for (class_1297 entity : world.method_27909()) {
            if (!(entity instanceof class_8113.class_8122)) continue;
            boolean ours = entity.method_5752().contains(KorimeSceneMod.MARKER_TAG)
                    || entity.method_5752().contains(SECONDARY_MARKER_TAG)
                    || entity.method_5752().stream().anyMatch(tag ->
                            tag.startsWith(LAYOUT_PREFIX) || tag.startsWith(SECONDARY_LOCK_PREFIX));
            if (ours) remove.add(entity);
        }
        for (class_1297 entity : remove) entity.method_31472();
        int count = remove.size();
        source.method_9226(() -> class_2561.method_43469("command.korime_scene.cleanup", count), false);
        return count == 0 ? Command.SINGLE_SUCCESS : count;
    }
}
