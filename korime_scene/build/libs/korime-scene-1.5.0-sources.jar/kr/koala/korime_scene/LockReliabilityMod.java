package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2323;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.UUID;

public final class LockReliabilityMod implements ModInitializer {
    private static final String SECONDARY_LOCK_PREFIX = KorimeSceneMod.MOD_ID + ":secondary_lock:";

    @Override
    public void onInitialize() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (world instanceof class_3218 serverWorld) cleanupAfterBreak(serverWorld, pos);
        });
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            LockState state = LockState.get(world);
            for (LockState.RemovedLock removed : state.pruneInvalid(world)) {
                removeMarkers(world, removed.lockId());
            }
        });
    }

    private static void cleanupAfterBreak(class_3218 world, class_2338 brokenPos) {
        LockState state = LockState.get(world);
        Set<UUID> removeIds = new HashSet<>();
        for (var entry : state.entries()) {
            class_2338 lockPos = class_2338.method_10092(entry.getKey());
            if (!world.method_22340(lockPos)) continue;
            LockState.LockEntry lock = entry.getValue();
            class_2680 current = world.method_8320(lockPos);
            String currentId = class_7923.field_41175.method_10221(current.method_26204()).toString();
            if (lockPos.equals(brokenPos)
                    || !currentId.equals(lock.blockId())
                    || !KorimeSceneMod.isLockable(world, lockPos, current)
                    || (current.method_26204() instanceof class_2323 && lockPos.method_10074().equals(brokenPos))) {
                removeIds.add(lock.lockId());
            }
        }
        for (UUID lockId : removeIds) {
            state.removeLock(lockId);
            removeMarkers(world, lockId);
        }
    }

    private static void removeMarkers(class_3218 world, UUID lockId) {
        String primaryLockTag = KorimeSceneMod.MOD_ID + ":" + lockId;
        String secondaryLockTag = SECONDARY_LOCK_PREFIX + lockId;
        List<class_1297> remove = new ArrayList<>();
        for (class_1297 entity : world.method_27909()) {
            boolean primary = entity.method_5752().contains(KorimeSceneMod.MARKER_TAG)
                    && entity.method_5752().contains(primaryLockTag);
            boolean secondary = entity.method_5752().contains(secondaryLockTag);
            if (primary || secondary) remove.add(entity);
        }
        for (class_1297 entity : remove) entity.method_31472();
    }
}
