package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2498;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import java.util.ArrayList;
import java.util.List;

public final class SceneToolsMod implements ModInitializer {
    public static final class_2960 EDIT_ITEM_PACKET = new class_2960(KorimeSceneMod.MOD_ID, "edit_item");
    public static final class_2960 CCTV_SAVE_PACKET = new class_2960(KorimeSceneMod.MOD_ID, "cctv_save");
    public static final class_2960 EVIDENCE_MAGNIFIER_SAVE_PACKET = new class_2960(KorimeSceneMod.MOD_ID, "evidence_magnifier_save");

    public static final class_2248 CCTV = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960(KorimeSceneMod.MOD_ID, "cctv"),
            new CctvBlock(class_4970.class_2251.method_9637()
                    .method_9632(0.8F)
                    .method_9626(class_2498.field_11533)
                    .method_22488())
    );

    public static final class_2591<CctvBlockEntity> CCTV_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(KorimeSceneMod.MOD_ID, "cctv"),
            FabricBlockEntityTypeBuilder.create(CctvBlockEntity::new, CCTV).build()
    );

    public static final class_1792 CCTV_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(KorimeSceneMod.MOD_ID, "cctv"),
            new class_1747(CCTV, new class_1792.class_1793())
    );

    public static final class_2248 ITEM_EDITOR = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960(KorimeSceneMod.MOD_ID, "item_editor"),
            new ItemEditorBlock(class_4970.class_2251.method_9637()
                    .method_9632(2.5F)
                    .method_9626(class_2498.field_11533))
    );

    public static final class_1792 ITEM_EDITOR_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(KorimeSceneMod.MOD_ID, "item_editor"),
            new class_1747(ITEM_EDITOR, new class_1792.class_1793())
    );

    public static final class_2248 EVIDENCE_MAGNIFIER = class_2378.method_10230(
            class_7923.field_41175,
            new class_2960(KorimeSceneMod.MOD_ID, "evidence"),
            new EvidenceMagnifierBlock(class_4970.class_2251.method_9637()
                    .method_9632(0.35F)
                    .method_9626(class_2498.field_11537)
                    .method_22488())
    );

    public static final class_2591<EvidenceMagnifierBlockEntity> EVIDENCE_MAGNIFIER_BLOCK_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            new class_2960(KorimeSceneMod.MOD_ID, "evidence"),
            FabricBlockEntityTypeBuilder.create(EvidenceMagnifierBlockEntity::new, EVIDENCE_MAGNIFIER).build()
    );

    public static final class_1792 EVIDENCE_MAGNIFIER_ITEM = class_2378.method_10230(
            class_7923.field_41178,
            new class_2960(KorimeSceneMod.MOD_ID, "evidence"),
            new class_1747(EVIDENCE_MAGNIFIER, new class_1792.class_1793())
    );

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(EVIDENCE_MAGNIFIER_SAVE_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    final class_2338 pos;
                    final String text;
                    try {
                        pos = buf.method_10811();
                        text = buf.method_10800(EvidenceMagnifierBlockEntity.MAX_TEXT_LENGTH);
                    } catch (RuntimeException ignored) {
                        return;
                    }

                    server.execute(() -> {
                        if (!player.method_37908().method_8320(pos).method_27852(EVIDENCE_MAGNIFIER)) return;
                        if (player.method_5649(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5) > 64.0) return;
                        if (!(player.method_37908().method_8321(pos) instanceof EvidenceMagnifierBlockEntity evidence)) return;
                        evidence.saveEvidence(text);
                    });
                });

        ServerPlayNetworking.registerGlobalReceiver(CCTV_SAVE_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    final class_2338 cctvPos;
                    final List<String> records = new ArrayList<>();
                    try {
                        cctvPos = buf.method_10811();
                        int count = Math.min(buf.method_10816(), CctvBlockEntity.MAX_RECORDS);
                        if (count < 0) return;
                        for (int i = 0; i < count; i++) {
                            records.add(buf.method_10800(CctvBlockEntity.MAX_RECORD_LENGTH));
                        }
                    } catch (RuntimeException ignored) {
                        return;
                    }

                    server.execute(() -> {
                        if (!player.method_37908().method_8320(cctvPos).method_27852(CCTV)) return;
                        if (player.method_5649(cctvPos.method_10263() + 0.5, cctvPos.method_10264() + 0.5, cctvPos.method_10260() + 0.5) > 64.0) return;
                        if (!(player.method_37908().method_8321(cctvPos) instanceof CctvBlockEntity cctv)) return;
                        cctv.setEvidence(records, true);
                    });
                });

        ServerPlayNetworking.registerGlobalReceiver(EDIT_ITEM_PACKET,
                (server, player, handler, buf, responseSender) -> {
                    final class_2338 editorPos;
                    final String name;
                    final String description;
                    try {
                        editorPos = buf.method_10811();
                        name = buf.method_10800(128);
                        description = buf.method_10800(512);
                    } catch (RuntimeException ignored) {
                        return;
                    }

                    server.execute(() -> {
                        if (!player.method_37908().method_8320(editorPos).method_27852(ITEM_EDITOR)) return;
                        if (player.method_5649(editorPos.method_10263() + 0.5, editorPos.method_10264() + 0.5, editorPos.method_10260() + 0.5) > 64.0) return;

                        class_1799 stack = player.method_6047();
                        if (stack.method_7960()) return;

                        String cleanName = name.trim();
                        String cleanDescription = description.trim();

                        if (cleanName.isEmpty()) stack.method_7925();
                        else stack.method_7977(net.minecraft.class_2561.method_43470(cleanName));

                        class_2487 root = stack.method_7948();
                        class_2487 display = root.method_10573("display", 10) ? root.method_10562("display") : new class_2487();
                        if (cleanDescription.isEmpty()) {
                            display.method_10551("Lore");
                        } else {
                            class_2499 lore = new class_2499();
                            String json = "{\"text\":\"" + escapeJson(cleanDescription) + "\",\"color\":\"light_purple\",\"italic\":false}";
                            lore.add(class_2519.method_23256(json));
                            display.method_10566("Lore", lore);
                        }
                        if (display.method_33133()) root.method_10551("display");
                        else root.method_10566("display", display);

                        player.field_7512.method_7623();
                    });
                });
    }

    private static String escapeJson(String value) {
        StringBuilder out = new StringBuilder(value.length() + 16);
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            switch (c) {
                case '"' -> out.append("\\\"");
                case '\\' -> out.append("\\\\");
                case '\n' -> out.append("\\n");
                case '\r' -> out.append("\\r");
                case '\t' -> out.append("\\t");
                default -> {
                    if (c < 0x20) out.append(String.format("\\u%04x", (int)c));
                    else out.append(c);
                }
            }
        }
        return out.toString();
    }
}
