package kr.koala.korime_scene;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;

public final class KorimeSceneClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        class_3929.method_17542(KorimeSceneMod.KEYPAD_SCREEN_HANDLER, KeypadScreen::new);
    }
}
