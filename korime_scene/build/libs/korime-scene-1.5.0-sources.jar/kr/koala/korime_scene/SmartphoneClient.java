package kr.koala.korime_scene;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_310;

public final class SmartphoneClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlock(SmartphoneMod.SMARTPHONE_BLOCK, class_1921.method_23581());

        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);
            if (!world.field_9236 || !stack.method_31574(SmartphoneMod.SMARTPHONE)) {
                return class_1271.method_22430(stack);
            }

            class_310 client = class_310.method_1551();
            if (client.field_1755 == null) {
                client.method_1507(new SmartphoneScreenV2(hand, stack.method_7972()));
            }
            return class_1271.method_22427(stack);
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.field_9236) {
                return class_1269.field_5811;
            }
            if (world.method_8321(hit.method_17777()) instanceof SmartphoneBlockEntity phone) {
                class_310 client = class_310.method_1551();
                if (client.field_1755 == null) {
                    client.method_1507(new SmartphoneScreenV2(phone.getData()));
                }
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });
    }
}
