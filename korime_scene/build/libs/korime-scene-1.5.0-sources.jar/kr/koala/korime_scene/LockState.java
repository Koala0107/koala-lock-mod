package kr.koala.korime_scene;

import java.util.Collection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_18;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_7923;

public final class LockState extends class_18 {
    private static final class_8645<LockState> TYPE = new class_8645<>(LockState::new, LockState::fromNbt, null);
    private static final String STORAGE_KEY = KorimeSceneMod.MOD_ID + "_locks";

    private final Map<Long, LockEntry> locks = new HashMap<>();

    public static LockState get(class_3218 world) {
        return world.method_17983().method_17924(TYPE, STORAGE_KEY);
    }

    public Optional<LockEntry> get(class_2338 pos) {
        return Optional.ofNullable(locks.get(pos.method_10063()));
    }

    public Collection<Map.Entry<Long, LockEntry>> entries() {
        return locks.entrySet();
    }

    public void put(class_2338 pos, LockEntry entry) {
        locks.put(pos.method_10063(), entry);
        method_80();
    }

    public void removeLock(UUID lockId) {
        boolean changed = locks.values().removeIf(entry -> entry.lockId().equals(lockId));
        if (changed) {
            method_80();
        }
    }

    public List<RemovedLock> pruneInvalid(class_3218 world) {
        boolean changed = false;
        List<RemovedLock> removedLocks = new ArrayList<>();
        var iterator = locks.entrySet().iterator();

        while (iterator.hasNext()) {
            Map.Entry<Long, LockEntry> mapEntry = iterator.next();
            class_2338 pos = class_2338.method_10092(mapEntry.getKey());
            if (!world.method_22340(pos)) {
                continue;
            }

            LockEntry lock = mapEntry.getValue();
            class_2680 current = world.method_8320(pos);
            String currentBlockId = class_7923.field_41175.method_10221(current.method_26204()).toString();

            if (!currentBlockId.equals(lock.blockId()) || !KorimeSceneMod.isLockable(world, pos, current)) {
                iterator.remove();
                removedLocks.add(new RemovedLock(pos.method_10062(), lock.lockId()));
                changed = true;
            }
        }

        if (changed) {
            method_80();
        }
        return removedLocks;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        class_2499 list = new class_2499();
        locks.forEach((packedPos, entry) -> {
            class_2487 value = new class_2487();
            value.method_10544("Pos", packedPos);
            value.method_10582("Type", entry.type());
            value.method_10582("Credential", entry.credential());
            value.method_10582("Lock", entry.lockId().toString());
            value.method_10582("Owner", entry.ownerId().toString());
            value.method_10582("Block", entry.blockId());
            list.add(value);
        });
        nbt.method_10566("Locks", list);
        return nbt;
    }

    private static LockState fromNbt(class_2487 nbt) {
        LockState state = new LockState();
        class_2499 list = nbt.method_10554("Locks", class_2520.field_33260);

        for (int index = 0; index < list.size(); index++) {
            class_2487 value = list.method_10602(index);
            try {
                long pos = value.method_10537("Pos");
                String type = value.method_10573("Type", class_2520.field_33258)
                        ? value.method_10558("Type")
                        : KorimeSceneMod.KEY_LOCK;
                String credential = value.method_10573("Credential", class_2520.field_33258)
                        ? value.method_10558("Credential")
                        : value.method_10558("Key");
                UUID lockId = UUID.fromString(value.method_10558("Lock"));
                UUID ownerId = UUID.fromString(value.method_10558("Owner"));
                String blockId = value.method_10558("Block");
                if (!credential.isBlank()) {
                    state.locks.put(pos, new LockEntry(type, credential, lockId, ownerId, blockId));
                }
            } catch (IllegalArgumentException ignored) {
                // Skip malformed entries instead of preventing the world from loading.
            }
        }
        return state;
    }

    public record LockEntry(String type, String credential, UUID lockId, UUID ownerId, String blockId) {
    }

    public record RemovedLock(class_2338 pos, UUID lockId) {
    }
}
