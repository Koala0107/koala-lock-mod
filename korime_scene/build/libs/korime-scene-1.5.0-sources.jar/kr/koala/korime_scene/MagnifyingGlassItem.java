package kr.koala.korime_scene;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_3419;

/** Magnifying glass: normal right-click inspects with the original custom sound; sneak-right-click keeps placement. */
public final class MagnifyingGlassItem extends class_1747 {
    public MagnifyingGlassItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        playUseSound(world, user);
        return class_1271.method_29237(user.method_5998(hand), world.method_8608());
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1657 player = context.method_8036();
        if (player != null && player.method_5715()) {
            return super.method_7884(context);
        }
        playUseSound(context.method_8045(), player);
        return class_1269.method_29236(context.method_8045().method_8608());
    }

    private static void playUseSound(class_1937 world, class_1657 user) {
        if (user == null || world.method_8608()) return;
        world.method_43128(
                null,
                user.method_23317(), user.method_23318(), user.method_23321(),
                DetectiveItemsMod.MAGNIFYING_GLASS_USE,
                class_3419.field_15248,
                1.0F,
                1.0F
        );
    }
}
