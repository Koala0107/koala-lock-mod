package kr.koala.korime_scene;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;

public final class SmartphoneItem extends class_1747 {
    public SmartphoneItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        return class_1271.method_29237(user.method_5998(hand), world.method_8608());
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        SmartphoneData data = SmartphoneData.fromStack(stack);
        if (data.finalized() && !data.title().isBlank()) {
            return class_2561.method_43470(data.title());
        }
        return class_2561.method_43471("item.korime_scene.smartphone");
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip,
                              class_1836 context) {
        SmartphoneData data = SmartphoneData.fromStack(stack);
        if (data.finalized() && !data.subtitle().isBlank()) {
            tooltip.add(class_2561.method_43470(data.subtitle()).method_27692(class_124.field_1076));
        }
    }
}
