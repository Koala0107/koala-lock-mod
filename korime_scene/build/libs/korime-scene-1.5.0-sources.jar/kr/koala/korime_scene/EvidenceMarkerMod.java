package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public final class EvidenceMarkerMod implements ModInitializer {
    public static final int COUNT = 15;
    public static final class_2248[] BLOCKS = new class_2248[COUNT];
    public static final class_1792[] ITEMS = new class_1792[COUNT];

    static {
        for (int i = 0; i < COUNT; i++) {
            int number = i + 1;
            class_2960 id = new class_2960(KorimeSceneMod.MOD_ID, "evidence_marker_" + number);
            class_2248 block = class_2378.method_10230(class_7923.field_41175, id,
                    new EvidenceMarkerBlock(class_4970.class_2251.method_9637()
                            .method_9632(0.2F)
                            .method_9626(class_2498.field_11543)
                            .method_22488()));
            class_1792 item = class_2378.method_10230(class_7923.field_41178, id, new class_1747(block, new class_1792.class_1793()));
            BLOCKS[i] = block;
            ITEMS[i] = item;
        }
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            for (class_1792 item : ITEMS) {
                entries.method_45421(item);
            }
        });
    }
}
