package kr.koala.korime_scene;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class BoundaryLineMod implements ModInitializer {
    public static final class_2248 HORIZONTAL = registerEdge("line_horizontal", "하얀선 가로", true);
    public static final class_2248 VERTICAL = registerEdge("line_vertical", "하얀선 세로", false);
    public static final class_2248 CORNER = register(
            "line_corner",
            "하얀선 모서리",
            new BoundaryCornerBlock(settings())
    );

    private static class_2248 register(String id, String displayName) {
        return register(id, displayName, new BoundaryLineBlock(settings()));
    }

    private static class_2248 registerEdge(String id, String displayName, boolean horizontal) {
        return register(id, displayName, new BoundaryEdgeBlock(settings(), horizontal));
    }

    private static class_4970.class_2251 settings() {
        return class_4970.class_2251.method_9637()
                .method_9632(0.05F)
                .method_22488()
                .method_9626(class_2498.field_11543);
    }

    private static class_2248 register(String id, String displayName, class_2248 block) {
        class_2378.method_10230(class_7923.field_41175, new class_2960(KorimeSceneMod.MOD_ID, id), block);
        class_2378.method_10230(
                class_7923.field_41178,
                new class_2960(KorimeSceneMod.MOD_ID, id),
                new NamedBlockItem(block, new class_1792.class_1793().method_7889(64), displayName)
        );
        return block;
    }

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(class_5321.method_29179(
                class_7924.field_44688,
                new class_2960(KorimeSceneMod.MOD_ID, "korime_scene")
        )).register(entries -> {
            entries.method_45421(HORIZONTAL);
            entries.method_45421(VERTICAL);
            entries.method_45421(CORNER);
        });
    }

    private static final class NamedBlockItem extends class_1747 {
        private final class_2561 name;
        private NamedBlockItem(class_2248 block, class_1793 settings, String name) {
            super(block, settings);
            this.name = class_2561.method_43470(name);
        }
        @Override public class_2561 method_7864(class_1799 stack) { return name; }
    }
}
