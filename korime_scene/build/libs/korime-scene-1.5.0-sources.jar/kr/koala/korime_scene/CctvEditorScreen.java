package kr.koala.korime_scene;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;
import java.util.ArrayList;
import java.util.List;

public final class CctvEditorScreen extends class_437 {
    private final class_2338 cctvPos;
    private final List<String> records;
    private final List<class_5481> previewLines = new ArrayList<>();
    private class_342 recordField;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    public CctvEditorScreen(class_2338 cctvPos, List<String> currentRecords) {
        super(class_2561.method_43470("CCTV 기록 편집"));
        this.cctvPos = cctvPos.method_10062();
        this.records = new ArrayList<>(currentRecords);
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(360, field_22789 - 20);
        panelHeight = Math.min(240, field_22790 - 20);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;

        int innerX = panelX + 18;
        int innerWidth = panelWidth - 36;

        recordField = method_37063(new class_342(field_22793,
                innerX, panelY + 48, innerWidth, 20,
                class_2561.method_43470("CCTV 기록 문장")));
        recordField.method_1880(CctvBlockEntity.MAX_RECORD_LENGTH);
        recordField.method_47404(class_2561.method_43470("증거로 보여줄 문장을 입력해줘"));

        int gap = 6;
        int smallWidth = (innerWidth - gap) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43470("문장 추가"), button -> addRecord())
                .method_46434(innerX, panelY + 74, smallWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("마지막 문장 삭제"), button -> deleteLast())
                .method_46434(innerX + smallWidth + gap, panelY + 74, smallWidth, 20).method_46431());

        int buttonWidth = (innerWidth - gap) / 2;
        method_37063(class_4185.method_46430(class_2561.method_43471("gui.cancel"), button -> method_25419())
                .method_46434(innerX, panelY + panelHeight - 34, buttonWidth, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("저장"), button -> saveFinal())
                .method_46434(innerX + buttonWidth + gap, panelY + panelHeight - 34, buttonWidth, 20).method_46431());

        rebuildPreview();
        recordField.method_25365(true);
    }

    private void addRecord() {
        String line = recordField.method_1882().trim();
        if (line.isEmpty() || records.size() >= CctvBlockEntity.MAX_RECORDS) return;
        records.add(line);
        recordField.method_1852("");
        rebuildPreview();
    }

    private void deleteLast() {
        if (records.isEmpty()) return;
        records.remove(records.size() - 1);
        rebuildPreview();
    }

    private void rebuildPreview() {
        previewLines.clear();
        int lineWidth = Math.max(80, panelWidth - 50);
        int start = Math.max(0, records.size() - 6);
        for (int i = start; i < records.size(); i++) {
            previewLines.addAll(field_22793.method_1728(class_2561.method_43470((i + 1) + ". " + records.get(i)), lineWidth));
        }
    }

    private void saveFinal() {
        String pending = recordField.method_1882().trim();
        if (!pending.isEmpty() && records.size() < CctvBlockEntity.MAX_RECORDS) {
            records.add(pending);
        }

        class_2540 buf = PacketByteBufs.create();
        buf.method_10807(cctvPos);
        buf.method_10804(records.size());
        for (String line : records) {
            buf.method_10788(line, CctvBlockEntity.MAX_RECORD_LENGTH);
        }
        ClientPlayNetworking.send(SceneToolsMod.CCTV_SAVE_PACKET, buf);
        method_25419();
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Keep the world visible, matching the smartphone editor.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF080A0D);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFE9ECEF);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + 30, 0xFF22272D);

        context.method_27534(field_22793, field_22785, panelX + panelWidth / 2, panelY + 11, 0xFFFFFFFF);

        int previewTop = panelY + 104;
        int previewBottom = panelY + panelHeight - 44;
        context.method_25294(panelX + 14, previewTop - 5, panelX + panelWidth - 14, previewBottom, 0xFFF7F7F7);

        int y = previewTop;
        int maxY = previewBottom - 10;
        for (class_5481 line : previewLines) {
            if (y > maxY) break;
            context.method_51430(field_22793, line, panelX + 20, y, 0xFF24282C, false);
            y += 11;
        }

        String count = records.size() + " / " + CctvBlockEntity.MAX_RECORDS;
        context.method_51439(field_22793, class_2561.method_43470(count), panelX + panelWidth - 18 - field_22793.method_1727(count), panelY + 35, 0xFF6B727A, false);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override public boolean method_25421() { return false; }
}
