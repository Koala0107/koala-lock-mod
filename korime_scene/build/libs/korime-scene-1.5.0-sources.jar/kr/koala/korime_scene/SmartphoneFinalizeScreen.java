package kr.koala.korime_scene;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Save dialog: choose the evidence item name/subtitle and confirm the save. */
public final class SmartphoneFinalizeScreen extends class_437 {
    private final SmartphoneScreenV2 parent;
    private final String initialTitle;
    private final String initialSubtitle;

    private class_342 titleField;
    private class_342 subtitleField;
    private int panelX;
    private int panelY;
    private int panelWidth;
    private int panelHeight;

    public SmartphoneFinalizeScreen(SmartphoneScreenV2 parent, String initialTitle, String initialSubtitle) {
        super(class_2561.method_43470("스마트폰 저장"));
        this.parent = parent;
        this.initialTitle = initialTitle;
        this.initialSubtitle = initialSubtitle;
    }

    @Override
    protected void method_25426() {
        panelWidth = Math.min(270, field_22789 - 20);
        panelHeight = Math.min(150, field_22790 - 16);
        panelX = (field_22789 - panelWidth) / 2;
        panelY = (field_22790 - panelHeight) / 2;
        int innerX = panelX + 18;
        int innerWidth = panelWidth - 36;

        titleField = method_37063(new class_342(field_22793,
                innerX, panelY + 43, innerWidth, 20,
                class_2561.method_43471("screen.korime_scene.smartphone.save.name")));
        titleField.method_1880(SmartphoneData.MAX_TITLE_LENGTH);
        titleField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.save.name_placeholder"));
        titleField.method_1852(initialTitle);

        subtitleField = method_37063(new class_342(field_22793,
                innerX, panelY + 78, innerWidth, 20,
                class_2561.method_43471("screen.korime_scene.smartphone.save.subtitle")));
        subtitleField.method_1880(SmartphoneData.MAX_SUBTITLE_LENGTH);
        subtitleField.method_1868(0x9B59D0);
        subtitleField.method_1860(0x9B59D0);
        subtitleField.method_47404(class_2561.method_43471("screen.korime_scene.smartphone.save.subtitle_placeholder")
                .method_27661().method_27694(style -> style.method_36139(0x9B59D0)));
        subtitleField.method_1852("");

        int gap = 8;
        int buttonWidth = (innerWidth - gap) / 2;
        method_37063(class_4185.method_46430(
                        class_2561.method_43471("screen.korime_scene.smartphone.save.cancel"),
                        button -> returnToEditor())
                .method_46434(innerX, panelY + 118, buttonWidth, 20)
                .method_46431());
        method_37063(class_4185.method_46430(
                        class_2561.method_43470("저장"),
                        button -> confirmSave())
                .method_46434(innerX + buttonWidth + gap, panelY + 118, buttonWidth, 20)
                .method_46431());

        titleField.method_25365(true);
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Intentionally no-op: do not put a translucent/dark layer over the game world.
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(panelX - 3, panelY - 3, panelX + panelWidth + 3, panelY + panelHeight + 3, 0xFF080A0D);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xFFF1F1F1);
        context.method_25294(panelX, panelY, panelX + panelWidth, panelY + 28, 0xFF252D35);

        context.method_27534(field_22793,
                class_2561.method_43470("스마트폰 저장"),
                panelX + panelWidth / 2, panelY + 10, 0xFFFFFFFF);
        context.method_51439(field_22793, class_2561.method_43471("screen.korime_scene.smartphone.save.name"),
                panelX + 18, panelY + 32, 0xFF33383D, false);
        context.method_51439(field_22793, class_2561.method_43471("screen.korime_scene.smartphone.save.subtitle"),
                panelX + 18, panelY + 67, 0xFF9B59D0, false);

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public void method_25419() {
        returnToEditor();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private void confirmSave() {
        parent.finalizeWithMetadata(titleField.method_1882(), subtitleField.method_1882());
    }

    private void returnToEditor() {
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }
}
